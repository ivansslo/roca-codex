/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export enum ThinkingLevel {
  HIGH = "HIGH"
}

export type AgentRole = 'architect' | 'developer' | 'pentester' | 'qa';

export interface Agent {
  id: string;
  name: string;
  role: AgentRole;
  model: string;
  avatar: string;
  systemPrompt: string;
}

export interface AgentStep {
  id: string;
  agentRole: AgentRole;
  title: string;
  status: 'pending' | 'running' | 'completed' | 'failed';
  timestamp: string;
  thoughts?: string;
  output?: string;
  actualModel?: string;
  toolsCalled?: {
    name: string;
    args: string;
    result: string;
  }[];
}

export interface GeneratedFile {
  name: string;
  path: string;
  content: string;
  language: string;
}

export interface Project {
  id: string;
  title: string;
  description: string;
  createdAt: string;
  userId?: string;
  status: 'idle' | 'running' | 'completed' | 'failed';
  useSearch: boolean;
  useThinking: boolean;
  quotaFallbackActive?: boolean;
  steps: AgentStep[];
  files: GeneratedFile[];
  securityScore?: string;
  qaCoverage?: string;
  releaseTag?: string;
}

export interface UserProfile {
  uid: string;
  email: string | null;
  displayName: string | null;
  photoURL: string | null;
}
