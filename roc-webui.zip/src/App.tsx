/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, FormEvent } from 'react';
import { 
  Cpu, 
  Code2, 
  ShieldCheck, 
  CheckCircle2, 
  Sparkles, 
  Search, 
  Zap, 
  Play, 
  Terminal as TerminalIcon,
  BookOpen, 
  History, 
  User, 
  LogOut, 
  Key,
  FolderGit2,
  AlertCircle,
  Code,
  ShieldAlert,
  Sliders,
  X,
  FileCode,
  Check
} from 'lucide-react';
import { onAuthStateChanged, type User as FirebaseUser } from 'firebase/auth';
import { auth, loginWithGoogle, logoutUser, saveProjectToDurableStorage, getProjectsFromDurableStorage } from './lib/firebase';
import { Project, AgentStep, GeneratedFile, ThinkingLevel } from './types';
import OrchestraVisualizer from './components/OrchestraVisualizer';
import TerminalView from './components/TerminalView';
import WorkspaceEditor from './components/WorkspaceEditor';
import ProjectHistory from './components/ProjectHistory';

// Task quick-start presets
const TASK_PRESETS = [
  {
    title: 'FastAPI Rate Limiter',
    desc: 'Build a secure FastAPI rate limiter in Python using Redis, handling IP-based token-bucket controls.'
  },
  {
    title: 'JWT Authentication',
    desc: 'Create an Express.js JWT authentication microservice with password hashing, login, and secure cookies.'
  },
  {
    title: 'PostgreSQL CRUD API',
    desc: 'Design a clean Node.js / PostgreSQL CRUD controller with comprehensive error-handling middleware.'
  },
  {
    title: 'Real-time WebSocket Server',
    desc: 'Design a real-time collaborative chat server using Node.js and Socket.io with room isolation and active connection maps.'
  },
  {
    title: 'Secure Cloud Uploads',
    desc: 'Create an AWS S3 pre-signed upload URL microservice in Go, handling custom metadata and cryptographic payload signatures.'
  },
  {
    title: 'Model Routing Pipeline',
    desc: 'Build an elegant Python agent router to split incoming requests dynamically based on context complexity and API budget rules.'
  }
];

export default function App() {
  const [user, setUser] = useState<FirebaseUser | null>(null);
  const [task, setTask] = useState<string>('');
  const [useSearch, setUseSearch] = useState<boolean>(true);
  const [useThinking, setUseThinking] = useState<boolean>(true);
  
  // Pipeline settings
  const [activeTab, setActiveTab] = useState<'graph' | 'terminal' | 'workspace'>('graph');
  const [projects, setProjects] = useState<Project[]>([]);
  const [activeProjectId, setActiveProjectId] = useState<string | null>(null);
  
  const [status, setStatus] = useState<'idle' | 'running' | 'completed' | 'failed'>('idle');
  const [activeStepIdx, setActiveStepIdx] = useState<number>(0);
  const [steps, setSteps] = useState<AgentStep[]>([]);
  const [files, setFiles] = useState<GeneratedFile[]>([]);
  const [metrics, setMetrics] = useState<{ securityScore?: string; qaCoverage?: string; releaseTag?: string }>({});
  const [quotaFallbackActive, setQuotaFallbackActive] = useState<boolean>(false);

  const [isRefactoring, setIsRefactoring] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Load User Authentication & Durable Projects History
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      setUser(currentUser);
      const hist = await getProjectsFromDurableStorage(currentUser);
      setProjects(hist);
      if (hist.length > 0) {
        loadProjectIntoState(hist[0]);
      }
    });
    return () => unsubscribe();
  }, []);

  const loadProjectIntoState = (project: Project) => {
    setActiveProjectId(project.id);
    setTask(project.description);
    setUseSearch(project.useSearch);
    setUseThinking(project.useThinking);
    setQuotaFallbackActive(!!project.quotaFallbackActive);
    setSteps(project.steps);
    setFiles(project.files);
    setMetrics({
      securityScore: project.securityScore,
      qaCoverage: project.qaCoverage,
      releaseTag: project.releaseTag
    });
    setStatus(project.status);
    setActiveStepIdx(project.steps.length - 1);
  };

  // Google Authentication Trigger
  const handleAuth = async () => {
    if (user) {
      await logoutUser();
      setUser(null);
      // Reload generic history
      const hist = await getProjectsFromDurableStorage(null);
      setProjects(hist);
    } else {
      const u = await loginWithGoogle();
      if (u) {
        setUser(u);
        const hist = await getProjectsFromDurableStorage(u);
        setProjects(hist);
        if (hist.length > 0) {
          loadProjectIntoState(hist[0]);
        }
      }
    }
  };

  // Run the Multi-Agent Orchestration Chain
  const handleTriggerPipeline = async (e?: FormEvent) => {
    if (e) e.preventDefault();
    if (!task.trim() || status === 'running') return;

    setStatus('running');
    setErrorMessage(null);
    setFiles([]);
    setMetrics({});
    setQuotaFallbackActive(false);
    setActiveTab('graph');

    // Create a temporary array of active orchestration steps to update the UI
    const tempSteps: AgentStep[] = [
      {
        id: 'step_architect',
        agentRole: 'architect',
        title: 'Architectural Blueprint Design',
        status: 'running',
        timestamp: new Date().toISOString(),
        thoughts: 'Initializing architect cognitive workspace...',
      },
      {
        id: 'step_developer',
        agentRole: 'developer',
        title: 'Source Code Generation',
        status: 'pending',
        timestamp: new Date().toISOString(),
      },
      {
        id: 'step_pentester',
        agentRole: 'pentester',
        title: 'Automated Security SAST & Pentest Review',
        status: 'pending',
        timestamp: new Date().toISOString(),
      },
      {
        id: 'step_qa',
        agentRole: 'qa',
        title: 'QA Unit Test & Release Validation',
        status: 'pending',
        timestamp: new Date().toISOString(),
      }
    ];

    setSteps(tempSteps);
    setActiveStepIdx(0);

    // Dynamic state simulator for nodes transitions during server compilation
    const runSimulator = () => {
      let currentIdx = 0;
      const interval = setInterval(() => {
        if (currentIdx < 3) {
          setSteps(prev => {
            const copy = [...prev];
            copy[currentIdx].status = 'completed';
            currentIdx += 1;
            copy[currentIdx].status = 'running';
            copy[currentIdx].thoughts = 'Initializing model core engines...';
            setActiveStepIdx(currentIdx);
            return copy;
          });
        } else {
          clearInterval(interval);
        }
      }, 9000); // Transitions approx every 9 seconds while the live server model runs
      return interval;
    };

    const simInterval = runSimulator();

    try {
      const response = await fetch('/api/run-orchestration', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ task, useSearch, useThinking })
      });

      clearInterval(simInterval);

      if (!response.ok) {
        const data = await response.json();
        throw new Error(data.error || 'Pipeline run failed.');
      }

      const { project } = await response.json();
      
      // Update with exact real results from Gemini
      setSteps(project.steps);
      setFiles(project.files);
      setQuotaFallbackActive(!!project.quotaFallbackActive);
      setMetrics({
        securityScore: project.securityScore,
        qaCoverage: project.qaCoverage,
        releaseTag: project.releaseTag
      });
      setStatus('completed');
      setActiveStepIdx(3);
      setActiveTab('workspace'); // automatically direct to editor to inspect code

      // Persist to Firebase / fallback localStorage
      await saveProjectToDurableStorage(project, user);
      
      // Reload projects list
      const updatedHistory = await getProjectsFromDurableStorage(user);
      setProjects(updatedHistory);
      setActiveProjectId(project.id);

    } catch (err: any) {
      clearInterval(simInterval);
      console.error(err);
      setStatus('failed');
      setErrorMessage(err.message || 'An error occurred during multi-agent simulation execution.');
      setSteps(prev => prev.map(s => s.status === 'running' ? { ...s, status: 'failed' } : s));
    }
  };

  // Perform a Live Refactoring Command using low-latency Gemini 3.1 Flash Lite
  const handleRefactorFile = async (fileIndex: number, instructions: string) => {
    if (files.length === 0 || isRefactoring) return;

    setIsRefactoring(true);
    setErrorMessage(null);

    const targetFile = files[fileIndex];

    try {
      const response = await fetch('/api/refactor', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ file: targetFile, instructions })
      });

      if (!response.ok) {
        const data = await response.json();
        throw new Error(data.error || 'Refactor operation failed.');
      }

      const { content } = await response.json();

      // Update state with updated file contents
      setFiles(prev => {
        const copy = [...prev];
        copy[fileIndex] = {
          ...copy[fileIndex],
          content
        };
        return copy;
      });

      // Update project history cache with the updated file
      const activeProj = projects.find(p => p.id === activeProjectId);
      if (activeProj) {
        const updatedFiles = [...activeProj.files];
        updatedFiles[fileIndex] = { ...updatedFiles[fileIndex], content };
        const updatedProject = { ...activeProj, files: updatedFiles };
        await saveProjectToDurableStorage(updatedProject, user);
        const hist = await getProjectsFromDurableStorage(user);
        setProjects(hist);
      }

    } catch (err: any) {
      console.error(err);
      setErrorMessage(err.message || 'Refactoring command failed to execute.');
    } finally {
      setIsRefactoring(false);
    }
  };

  const handleSelectHistoryProject = (id: string) => {
    const found = projects.find(p => p.id === id);
    if (found) {
      loadProjectIntoState(found);
    }
  };

  const handleDeleteHistoryProject = (id: string) => {
    // Delete from Local History / cache
    const existing = localStorage.getItem('roc_projects');
    if (existing) {
      const parsed = JSON.parse(existing);
      const filtered = parsed.filter((p: any) => p.id !== id);
      localStorage.setItem('roc_projects', JSON.stringify(filtered));
    }
    setProjects(prev => prev.filter(p => p.id !== id));
    if (activeProjectId === id) {
      setTask('');
      setSteps([]);
      setFiles([]);
      setMetrics({});
      setStatus('idle');
      setActiveProjectId(null);
    }
  };

  const handleClearLogs = () => {
    setSteps([]);
    setStatus('idle');
  };

  return (
    <div className="min-h-screen bg-[#070b13] text-slate-100 flex flex-col font-sans antialiased Selection:bg-cyan-500/30 selection:text-cyan-200">
      
      {/* Premium Header */}
      <header className="border-b border-slate-900 bg-[#090d16] px-6 py-4 flex flex-wrap justify-between items-center gap-4 relative z-50 shadow-lg">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-600 to-violet-600 flex items-center justify-center shadow-lg shadow-cyan-950/40 relative">
            <Cpu className="w-5 h-5 text-white" />
            <div className="absolute inset-0 rounded-xl border border-white/20" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-bold tracking-tight text-white font-mono">roc-webui</h1>
              <span className="px-2 py-0.5 rounded bg-cyan-950 text-cyan-400 text-[10px] font-mono border border-cyan-800/40">V1.2</span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">Multi-Agent Software Engineering Workspace</p>
          </div>
        </div>

        {/* User Auth Sync */}
        <div className="flex items-center gap-3">
          {user ? (
            <div className="flex items-center gap-3 px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800">
              {user.photoURL ? (
                <img referrerPolicy="no-referrer" src={user.photoURL} alt={user.displayName || 'User'} className="w-6 h-6 rounded-full border border-slate-700" />
              ) : (
                <div className="w-6 h-6 rounded-full bg-cyan-900 flex items-center justify-center text-xs text-cyan-300 border border-cyan-700">
                  <User className="w-3.5 h-3.5" />
                </div>
              )}
              <div className="text-left">
                <div className="text-xs font-semibold text-slate-200 max-w-[120px] truncate">{user.displayName || 'Ivan Suselo'}</div>
                <div className="text-[9px] text-slate-500 truncate max-w-[120px]">{user.email || 'ivansuselo@gmail.com'}</div>
              </div>
              <button 
                onClick={handleAuth}
                className="p-1 rounded text-slate-500 hover:text-rose-400 hover:bg-rose-950/20 transition-colors ml-1 cursor-pointer"
                title="Sign out"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <button
              onClick={handleAuth}
              className="px-4 py-2 rounded-lg border border-slate-800 hover:border-slate-700 bg-slate-900 text-slate-200 text-xs font-semibold font-mono flex items-center gap-2 transition-all hover:bg-slate-850 cursor-pointer shadow-md"
            >
              <User className="w-3.5 h-3.5 text-cyan-400" />
              Sync Firebase Auth
            </button>
          )}
        </div>
      </header>

      {/* Main Workspace Layout (Sidebar on right for history/persistence) */}
      <main className="flex-1 max-w-[1440px] w-full mx-auto p-4 lg:p-6 grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* Workspace Central Panels (9 cols) */}
        <div className="lg:col-span-9 space-y-6">

          {/* Project task triggering form */}
          <section className="bg-[#0f172a] rounded-xl border border-slate-800 p-6 shadow-xl relative overflow-hidden">
            <div className="absolute top-0 right-0 w-48 h-48 bg-gradient-to-bl from-cyan-500/5 to-transparent rounded-full blur-2xl pointer-events-none" />
            <div className="flex items-center gap-2 mb-4">
              <Sparkles className="w-5 h-5 text-cyan-400 animate-pulse" />
              <h2 className="text-sm font-semibold text-slate-200 uppercase tracking-wider font-mono">Operations Console</h2>
            </div>

            <form onSubmit={handleTriggerPipeline} className="space-y-4">
              <div className="relative">
                <textarea
                  value={task}
                  onChange={(e) => setTask(e.target.value)}
                  placeholder="Enter software design specifications (e.g. 'Build a JWT auth service with password hashing, secure tokens, and rate limiting in Python FastAPI')..."
                  className="w-full bg-[#080d16] border border-slate-800 focus:border-cyan-500/80 rounded-xl p-4 pr-12 text-sm text-slate-200 placeholder-slate-500 outline-none transition-all font-mono min-h-[90px] resize-y"
                  disabled={status === 'running'}
                />
                <div className="absolute right-3 bottom-3 text-[10px] text-slate-500 font-mono">
                  {task.length} chars
                </div>
              </div>

              {/* Task presets */}
              {status !== 'running' && task.length === 0 && (
                <div className="flex flex-col gap-2">
                  <span className="text-[10px] font-mono text-slate-500 uppercase">Operational Task Templates:</span>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                    {TASK_PRESETS.map((p, idx) => (
                      <button
                        key={idx}
                        type="button"
                        onClick={() => setTask(p.desc)}
                        className="p-3 text-left rounded-lg bg-slate-900 border border-slate-850 hover:border-slate-850 hover:bg-slate-800/40 transition-all text-xs cursor-pointer group"
                      >
                        <div className="font-semibold text-slate-200 flex items-center gap-1">
                          <Code className="w-3.5 h-3.5 text-cyan-400 group-hover:translate-x-0.5 transition-transform" />
                          {p.title}
                        </div>
                        <p className="text-[10px] text-slate-500 mt-1 line-clamp-2 leading-relaxed">{p.desc}</p>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Advanced controls parameters */}
              <div className="flex flex-wrap items-center justify-between gap-4 border-t border-slate-900/80 pt-4">
                <div className="flex flex-wrap items-center gap-4">
                  {/* Thinking level toggle */}
                  <label className="flex items-center gap-2.5 cursor-pointer group">
                    <input
                      type="checkbox"
                      checked={useThinking}
                      onChange={(e) => setUseThinking(e.target.checked)}
                      disabled={status === 'running'}
                      className="sr-only peer"
                    />
                    <div className="relative w-9 h-5 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-slate-400 peer-checked:after:bg-cyan-400 after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-cyan-950/80 peer-checked:border peer-checked:border-cyan-800/60" />
                    <span className="text-xs font-medium text-slate-400 peer-checked:text-cyan-400 font-mono flex items-center gap-1 select-none">
                      <Cpu className="w-3.5 h-3.5" />
                      ThinkingMode (HIGH)
                    </span>
                  </label>

                  {/* Search grounding toggle */}
                  <label className="flex items-center gap-2.5 cursor-pointer group">
                    <input
                      type="checkbox"
                      checked={useSearch}
                      onChange={(e) => setUseSearch(e.target.checked)}
                      disabled={status === 'running'}
                      className="sr-only peer"
                    />
                    <div className="relative w-9 h-5 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-slate-400 peer-checked:after:bg-emerald-400 after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-emerald-950/80 peer-checked:border peer-checked:border-emerald-800/60" />
                    <span className="text-xs font-medium text-slate-400 peer-checked:text-emerald-400 font-mono flex items-center gap-1 select-none">
                      <Search className="w-3.5 h-3.5" />
                      Google Search Grounding
                    </span>
                  </label>
                </div>

                <button
                  type="submit"
                  disabled={!task.trim() || status === 'running'}
                  className="px-5 py-3 rounded-xl bg-gradient-to-r from-cyan-600 to-violet-600 hover:from-cyan-500 hover:to-violet-500 text-slate-100 text-xs font-semibold font-mono flex items-center gap-2 transition-all shadow-lg shadow-cyan-950/30 hover:shadow-cyan-900/40 hover:-translate-y-0.5 disabled:from-slate-850 disabled:to-slate-850 disabled:text-slate-500 disabled:cursor-not-allowed disabled:transform-none cursor-pointer"
                >
                  {status === 'running' ? (
                    <>
                      <div className="w-4 h-4 border-2 border-slate-400 border-t-cyan-400 rounded-full animate-spin" />
                      COMPILING PIPELINE...
                    </>
                  ) : (
                    <>
                      <Play className="w-4 h-4" />
                      EXECUTE AGENT ORCHESTRA
                    </>
                  )}
                </button>
              </div>
            </form>

            {/* Error notifications */}
            {errorMessage && (
              <div className="mt-4 p-3.5 rounded-lg bg-rose-950/30 border border-rose-800/60 text-rose-300 text-xs flex items-center gap-3 font-mono">
                <AlertCircle className="w-5 h-5 text-rose-400 flex-shrink-0 animate-bounce" />
                <span>{errorMessage}</span>
              </div>
            )}

            {/* Fallback notification */}
            {quotaFallbackActive && (
              <div className="mt-4 p-3.5 rounded-lg bg-cyan-950/20 border border-cyan-800/40 text-cyan-300 text-xs flex flex-col gap-1.5 font-mono">
                <div className="flex items-center gap-2.5">
                  <Sparkles className="w-4 h-4 text-cyan-400 animate-pulse flex-shrink-0" />
                  <span className="font-semibold uppercase text-cyan-200">Resilient Eco-Routing & Simulation Active</span>
                </div>
                <p className="text-slate-400 text-[11px] leading-relaxed pl-6">
                  Your API Key has temporarily hit standard Gemini Pro rate limits or daily quotas.
                  To ensure a seamless, uninterrupted engineering experience, the orchestra has activated its high-fidelity
                  resilience engine. You can fully inspect the generated files, architecture, security findings, and unit tests!
                </p>
              </div>
            )}
          </section>

          {/* Metric Outcomes banner (if completed successfully) */}
          {status === 'completed' && metrics.releaseTag && (
            <section className="grid grid-cols-1 md:grid-cols-3 gap-4 bg-gradient-to-r from-[#0b162c] to-[#120b24] border border-slate-800/60 rounded-xl p-5 shadow-lg relative">
              <div className="absolute top-0 right-0 w-32 h-32 bg-cyan-500/5 rounded-full blur-2xl pointer-events-none" />
              
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-lg bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center">
                  <CheckCircle2 className="w-5 h-5 text-emerald-400 animate-pulse" />
                </div>
                <div>
                  <span className="text-[10px] font-mono text-slate-500 uppercase block">Certification Build</span>
                  <span className="text-xs font-semibold font-mono text-emerald-300">{metrics.releaseTag}</span>
                </div>
              </div>

              <div className="flex items-center gap-3 border-y border-slate-850 md:border-y-0 md:border-x md:px-4 py-3 md:py-0">
                <div className="w-9 h-9 rounded-lg bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center">
                  <ShieldCheck className="w-5 h-5 text-cyan-400" />
                </div>
                <div>
                  <span className="text-[10px] font-mono text-slate-500 uppercase block">Vulnerability Audit</span>
                  <span className="text-xs font-semibold font-mono text-cyan-300">Grade {metrics.securityScore} (SECURE)</span>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-lg bg-violet-500/10 border border-violet-500/30 flex items-center justify-center">
                  <Zap className="w-5 h-5 text-violet-400" />
                </div>
                <div>
                  <span className="text-[10px] font-mono text-slate-500 uppercase block">Test Harness coverage</span>
                  <span className="text-xs font-semibold font-mono text-violet-300">{metrics.qaCoverage} verified</span>
                </div>
              </div>
            </section>
          )}

          {/* Interactive Multi-Tab Dashboard Panel */}
          <section className="space-y-4">
            
            {/* Nav tabs */}
            <div className="flex border-b border-slate-900 gap-1 bg-[#0b1329]/60 p-1 rounded-lg max-w-sm">
              <button
                onClick={() => setActiveTab('graph')}
                className={`flex-1 py-2 text-xs font-semibold rounded font-mono transition-all duration-200 cursor-pointer ${
                  activeTab === 'graph'
                    ? 'bg-slate-900 border border-slate-800 text-cyan-400'
                    : 'text-slate-500 hover:text-slate-300'
                }`}
              >
                Orchestra Graph
              </button>
              <button
                onClick={() => setActiveTab('terminal')}
                className={`flex-1 py-2 text-xs font-semibold rounded font-mono transition-all duration-200 cursor-pointer ${
                  activeTab === 'terminal'
                    ? 'bg-slate-900 border border-slate-800 text-cyan-400'
                    : 'text-slate-500 hover:text-slate-300'
                }`}
              >
                Live Terminal
              </button>
              <button
                onClick={() => setActiveTab('workspace')}
                className={`flex-1 py-2 text-xs font-semibold rounded font-mono transition-all duration-200 cursor-pointer ${
                  activeTab === 'workspace'
                    ? 'bg-slate-900 border border-slate-800 text-cyan-400'
                    : 'text-slate-500 hover:text-slate-300'
                }`}
              >
                Code Workspace
              </button>
            </div>

            {/* Render selected panel */}
            <div className="transition-all duration-300">
              {activeTab === 'graph' && (
                <OrchestraVisualizer
                  activeStepIndex={activeStepIdx}
                  steps={steps}
                  status={status}
                  useSearch={useSearch}
                  useThinking={useThinking}
                />
              )}

              {activeTab === 'terminal' && (
                <TerminalView
                  steps={steps}
                  onClear={handleClearLogs}
                  status={status}
                />
              )}

              {activeTab === 'workspace' && (
                <WorkspaceEditor
                  files={files}
                  onRefactor={handleRefactorFile}
                  isRefactoring={isRefactoring}
                />
              )}
            </div>
          </section>

        </div>

        {/* Sidebar / Persistent logs history column (3 cols) */}
        <div className="lg:col-span-3 space-y-6">
          <ProjectHistory
            projects={projects}
            activeProjectId={activeProjectId}
            onSelectProject={handleSelectHistoryProject}
            onDeleteProject={handleDeleteHistoryProject}
          />
        </div>

      </main>

      {/* Humble Footer */}
      <footer className="border-t border-slate-900 bg-[#090d16] py-6 px-6 text-center text-[10px] text-slate-600 font-mono mt-12 flex flex-wrap justify-between items-center gap-4">
        <div>
          roc-webui is licensed under the Apache-2.0 open-source initiative.
        </div>
        <div className="flex items-center gap-1.5">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
          ROC NODE CORE: ONLINE
        </div>
      </footer>

    </div>
  );
}
