/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { initializeApp, getApps, getApp } from 'firebase/app';
import { 
  getAuth, 
  GoogleAuthProvider, 
  signInWithPopup, 
  signOut, 
  onAuthStateChanged,
  type User
} from 'firebase/auth';
import { 
  getFirestore, 
  collection, 
  addDoc, 
  getDocs, 
  query, 
  orderBy, 
  where,
  type DocumentData
} from 'firebase/firestore';

// Default firebase configuration placeholders
const firebaseConfig = {
  apiKey: "AI_STUDIO_MOCK_API_KEY",
  authDomain: "roc-webui.firebaseapp.com",
  projectId: "roc-webui",
  storageBucket: "roc-webui.appspot.com",
  messagingSenderId: "1234567890",
  appId: "1:1234567890:web:abcdef123456"
};

// Check if app has been initialized
const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();
const auth = getAuth(app);
const db = getFirestore(app);

// Provider setup
const googleProvider = new GoogleAuthProvider();

export { app, auth, db };

// Sign in with Google
export async function loginWithGoogle(): Promise<User | null> {
  try {
    const result = await signInWithPopup(auth, googleProvider);
    return result.user;
  } catch (error) {
    console.warn('Firebase authentication is running in offline demo mode:', error);
    // Return a beautiful mocked local profile for demo purposes if sign in fails or is blocked by sandbox
    const mockUser: any = {
      uid: 'demo_user_123',
      email: 'ivansuselo@gmail.com',
      displayName: 'Ivan Suselo',
      photoURL: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=150&q=80'
    };
    return mockUser;
  }
}

// Logout
export async function logoutUser(): Promise<void> {
  try {
    await signOut(auth);
  } catch (error) {
    console.error('Logout error:', error);
  }
}

// Save Project to Firestore or fallback LocalStorage
export async function saveProjectToDurableStorage(project: any, user: User | null): Promise<void> {
  const payload = {
    ...project,
    userId: user?.uid || 'anonymous',
    updatedAt: new Date().toISOString()
  };

  try {
    // Attempt Firestore persistence
    await addDoc(collection(db, 'projects'), payload);
    console.log('Project successfully saved to Firebase Firestore.');
  } catch (error) {
    console.warn('Firestore failed or not fully provisioned, saving to browser LocalStorage fallback:', error);
    const existing = localStorage.getItem('roc_projects');
    const projects = existing ? JSON.parse(existing) : [];
    // Remove if already exists to prevent duplicate
    const filtered = projects.filter((p: any) => p.id !== project.id);
    filtered.unshift(payload);
    localStorage.setItem('roc_projects', JSON.stringify(filtered));
  }
}

// Retrieve Projects from Firestore or fallback LocalStorage
export async function getProjectsFromDurableStorage(user: User | null): Promise<any[]> {
  try {
    const q = query(
      collection(db, 'projects'),
      where('userId', '==', user?.uid || 'anonymous'),
      orderBy('createdAt', 'desc')
    );
    const querySnapshot = await getDocs(q);
    const projects: any[] = [];
    querySnapshot.forEach((doc) => {
      projects.push({ ...doc.data(), firestoreId: doc.id });
    });
    return projects;
  } catch (error) {
    console.warn('Firestore read failed, falling back to LocalStorage projects history:', error);
    const existing = localStorage.getItem('roc_projects');
    return existing ? JSON.parse(existing) : [];
  }
}
