/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, useRef } from 'react';
import { 
  Terminal, 
  Trash2, 
  Play, 
  ChevronRight, 
  ChevronDown, 
  Search, 
  ShieldAlert, 
  Cpu, 
  CheckCircle2, 
  AlertTriangle,
  FileCode
} from 'lucide-react';
import { AgentStep } from '../types';

interface TerminalViewProps {
  steps: AgentStep[];
  onClear: () => void;
  status: 'idle' | 'running' | 'completed' | 'failed';
}

export default function TerminalView({ steps, onClear, status }: TerminalViewProps) {
  const [filter, setFilter] = useState<'all' | 'architect' | 'developer' | 'pentester' | 'qa'>('all');
  const [expandedSteps, setExpandedSteps] = useState<Record<string, boolean>>({
    step_architect: true,
    step_developer: true,
    step_pentester: true,
    step_qa: true
  });

  const terminalEndRef = useRef<HTMLDivElement>(null);

  // Auto scroll to bottom
  useEffect(() => {
    terminalEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [steps]);

  const toggleExpand = (id: string) => {
    setExpandedSteps(prev => ({
      ...prev,
      [id]: !prev[id]
    }));
  };

  const filteredSteps = steps.filter(step => {
    if (filter === 'all') return true;
    return step.agentRole === filter;
  });

  const getRoleIcon = (role: string) => {
    switch (role) {
      case 'architect': return <Cpu className="w-3.5 h-3.5 text-cyan-400" />;
      case 'developer': return <FileCode className="w-3.5 h-3.5 text-blue-400" />;
      case 'pentester': return <ShieldAlert className="w-3.5 h-3.5 text-amber-500" />;
      case 'qa': return <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />;
      default: return <Terminal className="w-3.5 h-3.5 text-slate-400" />;
    }
  };

  const getRoleBadgeColor = (role: string) => {
    switch (role) {
      case 'architect': return 'bg-cyan-950/60 border-cyan-800/40 text-cyan-400';
      case 'developer': return 'bg-blue-950/60 border-blue-800/40 text-blue-400';
      case 'pentester': return 'bg-amber-950/60 border-amber-850/40 text-amber-400';
      case 'qa': return 'bg-emerald-950/60 border-emerald-800/40 text-emerald-400';
      default: return 'bg-slate-800 border-slate-700 text-slate-300';
    }
  };

  return (
    <div id="terminal_view" className="bg-[#090d16] rounded-xl border border-slate-800 shadow-2xl overflow-hidden flex flex-col h-[500px] font-mono">
      {/* Terminal Title Bar */}
      <div className="bg-slate-900 border-b border-slate-800 px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="flex gap-1.5">
            <span className="w-3 h-3 rounded-full bg-rose-500/80" />
            <span className="w-3 h-3 rounded-full bg-amber-500/80" />
            <span className="w-3 h-3 rounded-full bg-emerald-500/80" />
          </div>
          <span className="text-xs text-slate-400 font-medium ml-2 flex items-center gap-1.5">
            <Terminal className="w-4 h-4 text-cyan-500 animate-pulse" />
            bash: roc-orchestration-bus
          </span>
        </div>

        {/* Quick actions & filters */}
        <div className="flex items-center gap-2">
          <select 
            value={filter} 
            onChange={(e: any) => setFilter(e.target.value)}
            className="bg-slate-950 border border-slate-800 text-slate-300 text-[10px] px-2 py-1 rounded outline-none focus:border-cyan-500"
          >
            <option value="all">ALL AGENTS</option>
            <option value="architect">ARCHITECT ONLY</option>
            <option value="developer">DEVELOPER ONLY</option>
            <option value="pentester">PENTESTER ONLY</option>
            <option value="qa">QA ONLY</option>
          </select>

          <button 
            onClick={onClear}
            className="p-1 rounded bg-slate-950 border border-slate-800 hover:border-rose-500 hover:text-rose-400 text-slate-500 transition-colors"
            title="Clear logs"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Terminal Body */}
      <div className="flex-1 p-4 overflow-y-auto space-y-4 text-xs text-slate-300">
        {/* Startup welcome system logs */}
        <div className="text-slate-500 space-y-1">
          <div>[system] Initializing ROC Autonomous Workspace Engine...</div>
          <div>[system] Mounting Express backend on port 3000...</div>
          <div>[system] Syncing Google API connections: OK</div>
          {status === 'idle' && (
            <div className="text-cyan-500 animate-pulse mt-2 flex items-center gap-1">
              <ChevronRight className="w-3.5 h-3.5 animate-bounce" />
              Waiting for user project prompt input...
            </div>
          )}
        </div>

        {/* Live Step Logs */}
        {filteredSteps.map((step) => {
          const isOpen = expandedSteps[step.id] ?? false;
          return (
            <div key={step.id} className="border border-slate-800/80 rounded-lg bg-slate-950/40 overflow-hidden">
              {/* Header */}
              <div 
                onClick={() => toggleExpand(step.id)}
                className="bg-slate-900/40 px-3 py-2 flex items-center justify-between cursor-pointer hover:bg-slate-900/60 transition-colors select-none"
              >
                <div className="flex items-center gap-2">
                  {isOpen ? <ChevronDown className="w-3.5 h-3.5 text-slate-500" /> : <ChevronRight className="w-3.5 h-3.5 text-slate-500" />}
                  {getRoleIcon(step.agentRole)}
                  <span className={`px-2 py-0.5 rounded border text-[9px] font-semibold tracking-wider font-mono uppercase ${getRoleBadgeColor(step.agentRole)}`}>
                    {step.agentRole}
                  </span>
                  <span className="font-semibold text-slate-200">{step.title}</span>
                </div>
                <div className="flex items-center gap-3 text-[10px] text-slate-500">
                  <span>{new Date(step.timestamp).toLocaleTimeString()}</span>
                  <span className={`w-1.5 h-1.5 rounded-full ${
                    step.status === 'completed' ? 'bg-emerald-500' :
                    step.status === 'running' ? 'bg-amber-400 animate-pulse' :
                    'bg-slate-600'
                  }`} />
                </div>
              </div>

              {/* Expansions */}
              {isOpen && (
                <div className="p-3 border-t border-slate-900/80 bg-[#070b12] space-y-3 font-mono leading-relaxed text-slate-300">
                  {/* Internal Thoughts processing (Thinking Mode) */}
                  {step.thoughts && (
                    <div className="p-3 rounded bg-amber-950/10 border border-amber-900/20 text-amber-300/90 italic relative">
                      <div className="flex items-center gap-1 text-[10px] text-amber-500/80 uppercase font-mono tracking-wider font-semibold mb-1">
                        <Cpu className="w-3 h-3 animate-spin" />
                        Internal LLM Cognition Track
                      </div>
                      "{step.thoughts}"
                    </div>
                  )}

                  {/* Tool execution block */}
                  {step.toolsCalled && step.toolsCalled.map((tool, idx) => (
                    <div key={idx} className="bg-slate-900/50 border border-slate-800/40 rounded p-2 text-[11px] space-y-1">
                      <div className="flex items-center gap-1.5 text-cyan-400 font-semibold">
                        <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
                        tool_call: {tool.name}()
                      </div>
                      {tool.args && (
                        <div className="text-slate-500 font-mono text-[10px]">
                          Arguments: <span className="text-slate-400">{tool.args}</span>
                        </div>
                      )}
                      {tool.result && (
                        <div className="text-emerald-400 font-mono text-[10px] mt-0.5">
                          Result: <span className="text-slate-300">{tool.result}</span>
                        </div>
                      )}
                    </div>
                  ))}

                  {/* Actual response payload */}
                  <div className="whitespace-pre-wrap font-mono text-slate-300 bg-slate-950/80 border border-slate-900 p-3 rounded overflow-x-auto text-[11px] leading-relaxed max-h-[350px]">
                    {step.output}
                  </div>
                </div>
              )}
            </div>
          );
        })}

        {/* Live Running logs indicator */}
        {status === 'running' && (
          <div className="flex items-center gap-2 text-amber-400 text-xs py-2">
            <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping" />
            <span>Agent stream processor busy... Executing model generation step.</span>
          </div>
        )}

        <div ref={terminalEndRef} />
      </div>
    </div>
  );
}
