/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { 
  FolderGit2, 
  History, 
  ShieldAlert, 
  Activity, 
  Trash2, 
  ChevronRight, 
  ExternalLink,
  GitBranch,
  BarChart2,
  Clock
} from 'lucide-react';
import { Project } from '../types';

interface ProjectHistoryProps {
  projects: Project[];
  activeProjectId: string | null;
  onSelectProject: (id: string) => void;
  onDeleteProject: (id: string) => void;
}

export default function ProjectHistory({
  projects,
  activeProjectId,
  onSelectProject,
  onDeleteProject
}: ProjectHistoryProps) {
  
  // Calculate aggregate stats
  const totalProjects = projects.length;
  
  const completedProjects = projects.filter(p => p.status === 'completed');
  
  const avgCoverage = completedProjects.length > 0 
    ? Math.round(completedProjects.reduce((acc, curr) => {
        const value = parseInt(curr.qaCoverage || '0');
        return acc + value;
      }, 0) / completedProjects.length)
    : 0;

  // Grade stats
  const grades = completedProjects.map(p => p.securityScore || 'A');
  const topGrade = grades.length > 0 
    ? grades.reduce((acc, curr) => (curr < acc ? curr : acc), 'Z')
    : 'N/A';

  return (
    <div id="project_history" className="bg-[#0f172a] rounded-xl border border-slate-800 p-5 shadow-xl space-y-6">
      {/* Header */}
      <div className="flex items-center gap-2 border-b border-slate-800/80 pb-4">
        <History className="w-5 h-5 text-cyan-400" />
        <div>
          <h2 className="text-sm font-semibold text-slate-100 uppercase tracking-wider font-mono">ROC Operations Log</h2>
          <p className="text-[10px] text-slate-500 font-mono">Persistent historical records log.</p>
        </div>
      </div>

      {/* Aggregate Stats Dashboard */}
      <div className="grid grid-cols-3 gap-2 bg-[#090d16] p-3 rounded-lg border border-slate-850">
        <div className="text-center">
          <span className="text-[9px] font-mono text-slate-500 block uppercase">Releases</span>
          <span className="text-sm font-bold font-mono text-slate-100">{totalProjects}</span>
        </div>
        <div className="text-center border-x border-slate-800/80">
          <span className="text-[9px] font-mono text-slate-500 block uppercase">QA Cover</span>
          <span className="text-sm font-bold font-mono text-emerald-400">{avgCoverage}%</span>
        </div>
        <div className="text-center">
          <span className="text-[9px] font-mono text-slate-500 block uppercase">Peak Sec</span>
          <span className="text-sm font-bold font-mono text-cyan-400">{topGrade}</span>
        </div>
      </div>

      {/* Projects List */}
      <div className="space-y-2 max-h-[400px] overflow-y-auto pr-1">
        {projects.length === 0 ? (
          <div className="text-center py-8 text-slate-500 font-mono text-xs">
            <FolderGit2 className="w-8 h-8 text-slate-700 mx-auto mb-2" />
            No history recorded yet.
          </div>
        ) : (
          projects.map((proj) => {
            const isActive = proj.id === activeProjectId;
            const formattedDate = new Date(proj.createdAt).toLocaleDateString(undefined, {
              month: 'short',
              day: 'numeric',
              hour: '2-digit',
              minute: '2-digit'
            });

            return (
              <div
                key={proj.id}
                className={`group relative rounded-lg border p-3 flex items-center justify-between transition-all duration-200 cursor-pointer ${
                  isActive
                    ? 'bg-cyan-500/5 border-cyan-500/30 text-cyan-300'
                    : 'hover:bg-slate-800/40 border-slate-850 hover:border-slate-800 text-slate-400'
                }`}
                onClick={() => onSelectProject(proj.id)}
              >
                <div className="flex-1 min-w-0 pr-3">
                  <div className="flex items-center gap-1.5 mb-1 text-[10px] text-slate-500 font-mono">
                    <Clock className="w-3 h-3" />
                    <span>{formattedDate}</span>
                    {proj.releaseTag && (
                      <span className="px-1.5 py-0.2 rounded bg-slate-800 text-slate-300 text-[9px] font-medium border border-slate-700/60 ml-1">
                        {proj.releaseTag}
                      </span>
                    )}
                  </div>
                  <h3 className={`text-xs font-semibold font-mono truncate ${isActive ? 'text-cyan-300' : 'text-slate-200'}`}>
                    {proj.title}
                  </h3>
                  
                  {/* Miniature specs panel */}
                  {proj.status === 'completed' && (
                    <div className="flex items-center gap-3 mt-1.5 text-[9px] font-mono text-slate-500">
                      <span className="flex items-center gap-1">
                        <Activity className="w-3 h-3 text-emerald-500" />
                        QA: <span className="text-emerald-400">{proj.qaCoverage}</span>
                      </span>
                      <span className="flex items-center gap-1">
                        <ShieldAlert className="w-3 h-3 text-amber-500" />
                        Sec: <span className="text-amber-400">{proj.securityScore}</span>
                      </span>
                    </div>
                  )}
                </div>

                <div className="flex items-center gap-1.5">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onDeleteProject(proj.id);
                    }}
                    className="p-1 rounded text-slate-600 hover:text-rose-400 hover:bg-rose-950/20 transition-colors opacity-0 group-hover:opacity-100 cursor-pointer"
                    title="Delete record"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                  <ChevronRight className={`w-4 h-4 transition-transform ${isActive ? 'translate-x-0.5 text-cyan-400' : 'text-slate-600'}`} />
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}
