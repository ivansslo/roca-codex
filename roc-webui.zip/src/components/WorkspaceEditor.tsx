/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, FormEvent } from 'react';
import { 
  FileCode, 
  Copy, 
  Check, 
  Download, 
  Sparkles, 
  RefreshCw,
  Code2,
  Lock,
  ChevronRight
} from 'lucide-react';
import { GeneratedFile } from '../types';

interface WorkspaceEditorProps {
  files: GeneratedFile[];
  onRefactor: (fileIndex: number, instructions: string) => Promise<void>;
  isRefactoring: boolean;
}

export default function WorkspaceEditor({ files, onRefactor, isRefactoring }: WorkspaceEditorProps) {
  const [activeFileIdx, setActiveFileIdx] = useState<number>(0);
  const [copied, setCopied] = useState<boolean>(false);
  const [refactorInput, setRefactorInput] = useState<string>('');

  if (files.length === 0) {
    return (
      <div id="workspace_editor" className="bg-[#0f172a] border border-slate-800 rounded-xl p-12 text-center shadow-xl">
        <Code2 className="w-12 h-12 text-slate-600 mx-auto mb-4" />
        <h3 className="text-base font-semibold text-slate-300">Workspace Empty</h3>
        <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
          No generated code assets are currently loaded. Run a project task or trigger an orchestrator pipeline above.
        </p>
      </div>
    );
  }

  const activeFile = files[activeFileIdx] || files[0];

  const handleCopy = () => {
    if (!activeFile) return;
    navigator.clipboard.writeText(activeFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    if (!activeFile) return;
    const blob = new Blob([activeFile.content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = activeFile.name;
    link.click();
    URL.revokeObjectURL(url);
  };

  const handleRefactorSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!refactorInput.trim() || isRefactoring) return;
    onRefactor(activeFileIdx, refactorInput);
    setRefactorInput('');
  };

  return (
    <div id="workspace_editor" className="bg-[#0f172a] rounded-xl border border-slate-800 shadow-2xl overflow-hidden grid grid-cols-1 md:grid-cols-12 min-h-[500px]">
      {/* Left Sidebar: Files explorer (3 cols) */}
      <div className="md:col-span-3 border-r border-slate-800 bg-[#0b1329]/80 flex flex-col">
        <div className="p-4 border-b border-slate-800 bg-slate-900/40 flex items-center justify-between">
          <span className="text-xs font-semibold text-slate-200 uppercase tracking-wider font-mono">Workspace Files</span>
          <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-400 border border-slate-700/50">
            {files.length} items
          </span>
        </div>

        <div className="flex-1 p-2 space-y-1 overflow-y-auto max-h-[400px] md:max-h-none">
          {files.map((file, idx) => (
            <button
              key={idx}
              onClick={() => setActiveFileIdx(idx)}
              className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-lg text-left text-xs font-mono transition-all duration-200 cursor-pointer ${
                idx === activeFileIdx
                  ? 'bg-cyan-500/10 border border-cyan-500/30 text-cyan-300'
                  : 'hover:bg-slate-800/60 border border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              <FileCode className={`w-4 h-4 ${idx === activeFileIdx ? 'text-cyan-400' : 'text-slate-500'}`} />
              <div className="truncate flex-1">
                <div className="truncate text-slate-100 font-medium">{file.name}</div>
                <div className="text-[10px] text-slate-500 truncate mt-0.5">{file.path}</div>
              </div>
              <ChevronRight className={`w-3.5 h-3.5 transition-transform ${idx === activeFileIdx ? 'rotate-90 text-cyan-400' : 'text-slate-600'}`} />
            </button>
          ))}
        </div>
      </div>

      {/* Right Area: Interactive Editor & Refactor Workspace (9 cols) */}
      <div className="md:col-span-9 flex flex-col bg-[#080d16] overflow-hidden">
        {/* Editor Title Bar */}
        <div className="px-5 py-3 border-b border-slate-800 bg-slate-900/20 flex flex-wrap justify-between items-center gap-3">
          <div className="flex items-center gap-2.5">
            <FileCode className="w-5 h-5 text-cyan-400" />
            <div>
              <span className="text-xs font-mono text-slate-100 font-medium">{activeFile.name}</span>
              <span className="text-[10px] text-slate-500 block font-mono mt-0.5">{activeFile.path}</span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleCopy}
              className="px-3 py-1.5 rounded-md border border-slate-800 hover:border-slate-700 hover:bg-slate-800/40 text-slate-400 hover:text-slate-200 text-xs font-mono transition-all flex items-center gap-1.5 cursor-pointer"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              {copied ? 'Copied' : 'Copy'}
            </button>
            <button
              onClick={handleDownload}
              className="px-3 py-1.5 rounded-md border border-slate-800 hover:border-slate-700 hover:bg-slate-800/40 text-slate-400 hover:text-slate-200 text-xs font-mono transition-all flex items-center gap-1.5 cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              Download
            </button>
          </div>
        </div>

        {/* Code Content Box */}
        <div className="flex-1 overflow-auto max-h-[350px] md:max-h-none border-b border-slate-850 p-4 font-mono text-xs text-slate-300 bg-[#060a10]">
          <pre className="grid grid-cols-12 gap-4">
            {/* Line Numbers column */}
            <div className="col-span-1 text-right text-slate-600 select-none border-r border-slate-900 pr-3 font-mono text-[11px] leading-relaxed">
              {activeFile.content.split('\n').map((_, idx) => (
                <div key={idx}>{idx + 1}</div>
              ))}
            </div>
            {/* Real Code Body */}
            <code className="col-span-11 leading-relaxed whitespace-pre font-mono text-[11px] text-slate-200 overflow-x-auto">
              {activeFile.content}
            </code>
          </pre>
        </div>

        {/* Gemini Code Refactor Command Bar */}
        <div className="p-4 bg-slate-900/40 border-t border-slate-850">
          <form onSubmit={handleRefactorSubmit} className="flex gap-2">
            <div className="relative flex-1">
              <input
                type="text"
                value={refactorInput}
                onChange={(e) => setRefactorInput(e.target.value)}
                disabled={isRefactoring}
                placeholder="Instruct Gemini to edit or refactor this code file (e.g. 'Add input validation' or 'Use dotenv')..."
                className="w-full bg-[#070b13] border border-slate-800 focus:border-cyan-500/80 rounded-lg px-3 py-2.5 pl-9 text-xs text-slate-200 placeholder-slate-500 outline-none transition-all font-mono"
              />
              <Sparkles className="w-4 h-4 text-cyan-400 absolute left-3 top-3 animate-pulse" />
            </div>
            <button
              type="submit"
              disabled={!refactorInput.trim() || isRefactoring}
              className="px-4 py-2.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-slate-100 text-xs font-semibold font-mono flex items-center gap-2 transition-colors duration-200 shadow-md shadow-cyan-900/20 disabled:bg-slate-850 disabled:border-slate-800 disabled:text-slate-500 disabled:cursor-not-allowed cursor-pointer"
            >
              {isRefactoring ? (
                <>
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  REFACTORING...
                </>
              ) : (
                <>
                  <Sparkles className="w-3.5 h-3.5" />
                  REFACTOR
                </>
              )}
            </button>
          </form>
          <div className="text-[10px] text-slate-500 font-mono mt-1.5 flex items-center gap-1">
            <span className="w-1 h-1 rounded-full bg-cyan-400" />
            Powering low-latency micro-edits with models/gemini-3.1-flash-lite.
          </div>
        </div>
      </div>
    </div>
  );
}
