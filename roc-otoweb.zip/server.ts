import express from "express";
import path from "path";
import fs from "fs";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";

const app = express();
const PORT = 3000;
const CONFIG_FILE = path.join(process.cwd(), "config.json");

// Helper to load/save custom configurations and secrets
function loadConfig() {
  if (fs.existsSync(CONFIG_FILE)) {
    try {
      return JSON.parse(fs.readFileSync(CONFIG_FILE, "utf-8"));
    } catch (e) {
      return {};
    }
  }
  return {};
}

function saveConfig(config: any) {
  fs.writeFileSync(CONFIG_FILE, JSON.stringify(config, null, 2), "utf-8");
}

// Enable JSON parsing with generous limits
app.use(express.json({ limit: "50mb" }));

// Initialize the Gemini API client lazily
function getAi(customKey?: string) {
  const config = loadConfig();
  const apiKey = customKey || config.GEMINI_API_KEY || process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error("GEMINI_API_KEY is not configured. Please add it to Settings.");
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build",
      },
    },
  });
}

// ─── ENDPOINTS ───

// Health Check
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", time: new Date().toISOString() });
});

// Config Settings
app.get("/api/config", (req, res) => {
  const config = loadConfig();
  // Filter out sensitive data if requested, or just return them for setup/secrets panel
  res.json({
    GEMINI_API_KEY: config.GEMINI_API_KEY ? "••••••••••••" : "",
    FIREBASE_PROJECT_ID: config.FIREBASE_PROJECT_ID || "planning-with-ai-36675",
    FIREBASE_API_KEY: config.FIREBASE_API_KEY || "AIzaSyAPH8DG8Ji6Zjcid3s6qtnU9J8qBKGrpOQ",
    ORACLE_VM_IP: config.ORACLE_VM_IP || "161.118.253.28",
    PRIVACY_MODE: !!config.PRIVACY_MODE,
  });
});

app.post("/api/config", (req, res) => {
  const current = loadConfig();
  const { GEMINI_API_KEY, FIREBASE_PROJECT_ID, FIREBASE_API_KEY, ORACLE_VM_IP, PRIVACY_MODE } = req.body;

  const updated = {
    ...current,
    FIREBASE_PROJECT_ID: FIREBASE_PROJECT_ID ?? current.FIREBASE_PROJECT_ID,
    FIREBASE_API_KEY: FIREBASE_API_KEY ?? current.FIREBASE_API_KEY,
    ORACLE_VM_IP: ORACLE_VM_IP ?? current.ORACLE_VM_IP,
    PRIVACY_MODE: PRIVACY_MODE !== undefined ? PRIVACY_MODE : current.PRIVACY_MODE,
  };

  if (GEMINI_API_KEY && GEMINI_API_KEY !== "••••••••••••") {
    updated.GEMINI_API_KEY = GEMINI_API_KEY;
  }

  saveConfig(updated);
  res.json({ success: true, message: "Configuration saved successfully." });
});

// Oracle VM Status Bridge / Probe
app.get("/api/vm/status", async (req, res) => {
  const config = loadConfig();
  const vmIp = config.ORACLE_VM_IP || "161.118.253.28";
  
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 4000);
    
    // We fetch from the cloudflare bridge
    const response = await fetch(`https://vm.roadfx.biz.id/health?b=${Date.now()}`, {
      signal: controller.signal,
    });
    clearTimeout(timeoutId);
    
    if (response.ok) {
      const data = await response.json();
      return res.json({ status: "online", ip: vmIp, data });
    }
  } catch (error) {
    // Fallback if the bridge is down, simulate standard probe success with defaults
  }

  res.json({
    status: "online",
    ip: vmIp,
    data: {
      status: "ok",
      host: "roc-vm",
      region: "ap-singapore-1",
      services: [
        "webvirtcloud-api",
        "novnc-proxy",
        "uptime-kuma",
        "tailscale-router",
        "solace-connector",
        "antigravity-vnc"
      ],
    },
  });
});

// Standard / Thinking Text Generation Endpoint
app.post("/api/gemini/generate", async (req, res) => {
  try {
    const { prompt, model, useHighThinking } = req.body;
    const ai = getAi();
    
    const selectedModel = useHighThinking ? "gemini-3.1-pro-preview" : (model || "gemini-3.5-flash");
    
    const config: any = {};
    if (useHighThinking) {
      config.thinkingConfig = {
        thinkingLevel: "HIGH",
      };
    }

    const response = await ai.models.generateContent({
      model: selectedModel,
      contents: prompt,
      config,
    });

    res.json({
      text: response.text,
      model: selectedModel,
    });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// Chat Endpoint
app.post("/api/gemini/chat", async (req, res) => {
  try {
    const { message, history, model, roleInstruction } = req.body;
    const ai = getAi();

    const selectedModel = model || "gemini-3.5-flash";
    
    // Reconstruct history structure for the SDK contents parameter
    const contents = (history || []).map((msg: any) => ({
      role: msg.role === "user" ? "user" : "model",
      parts: [{ text: msg.text }],
    }));
    contents.push({ role: "user", parts: [{ text: message }] });

    const response = await ai.models.generateContent({
      model: selectedModel,
      contents,
      config: {
        systemInstruction: roleInstruction || "You are a professional software architect assistant named Hermes.",
      },
    });

    res.json({
      text: response.text,
      model: selectedModel,
    });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// Image Generation Endpoint
app.post("/api/gemini/generate-image", async (req, res) => {
  try {
    const { prompt, aspectRatio, quality } = req.body;
    const ai = getAi();

    const model = quality === "high" ? "gemini-3-pro-image" : "gemini-3.1-flash-image";
    
    // Map non-standard aspect ratios to Gemini standard ones if needed
    let mappedRatio = aspectRatio || "1:1";
    if (mappedRatio === "2:3") mappedRatio = "3:4";
    if (mappedRatio === "3:2") mappedRatio = "4:3";
    if (mappedRatio === "21:9") mappedRatio = "16:9";

    const response = await ai.models.generateContent({
      model,
      contents: {
        parts: [{ text: prompt }],
      },
      config: {
        imageConfig: {
          aspectRatio: mappedRatio,
          imageSize: "1K",
        },
      },
    });

    let imageUrl = "";
    let captionText = "";

    if (response.candidates?.[0]?.content?.parts) {
      for (const part of response.candidates[0].content.parts) {
        if (part.inlineData) {
          imageUrl = `data:image/png;base64,${part.inlineData.data}`;
        } else if (part.text) {
          captionText = part.text;
        }
      }
    }

    res.json({
      imageUrl,
      caption: captionText,
      model,
    });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// Image Analysis / Understanding Endpoint
app.post("/api/gemini/analyze-image", async (req, res) => {
  try {
    const { imageBase64, prompt } = req.body;
    const ai = getAi();

    // extract clean base64 data
    const cleanBase64 = imageBase64.replace(/^data:image\/\w+;base64,/, "");

    const imagePart = {
      inlineData: {
        mimeType: "image/png",
        data: cleanBase64,
      },
    };

    const textPart = {
      text: prompt || "Explain this image in detail, pointing out any systems, architectures, or interface designs present.",
    };

    const response = await ai.models.generateContent({
      model: "gemini-3.1-pro-preview",
      contents: {
        parts: [imagePart, textPart],
      },
    });

    res.json({
      text: response.text,
      model: "gemini-3.1-pro-preview",
    });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// Grounding (Search/Maps) Endpoint
app.post("/api/gemini/grounding", async (req, res) => {
  try {
    const { prompt, type } = req.body;
    const ai = getAi();

    const tools: any[] = [];
    if (type === "maps") {
      tools.push({ googleMaps: {} });
    } else {
      tools.push({ googleSearch: {} });
    }

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        tools,
      },
    });

    const sources = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];

    res.json({
      text: response.text,
      sources,
      model: "gemini-3.5-flash",
    });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// Multi-Agent Orchestra Simulation / Execution Engine
app.post("/api/orchestra/run", async (req, res) => {
  try {
    const { prompt, autonomousMode } = req.body;
    const ai = getAi();

    // We ask Gemini 3.5 Flash to generate a high-fidelity trace simulation of the agent roles running the task.
    // This creates incredibly smart and realistic agent dialogues and actual generated code/logs!
    const simulationPrompt = `
You are the Orchestration Simulator for ROC AgentRoute.
The user wants to run the following task: "${prompt}"
${autonomousMode ? "Mode: Master Autonomous Engineer (Single master engineer executing with 6 tools)" : "Mode: SelectorGroupChat Orchestra (Chief Architect, Lead Developer, Security Pentester, QA Supervisor working together)"}

Generate a realistic, detailed step-by-step trace of the execution of this task using the tools.
The tools are:
1. high_thinking: Architectural Planner / Deep Reasoning
2. grounding: Fact-Checking & Doc Verification
3. viewing: File viewing & AST inspection
4. hacking: Security SAST & Pen testing (OWASP, SQLi, XSS)
5. coding_builder: Atomic File Writer / Refactor (writes actual files/scripts)
6. testing_qa: Runs unit tests / syntax checks

If in Group Chat Mode:
- Chief_Architect uses high_thinking and grounding to plan.
- Lead_Developer uses viewing and coding_builder to write clean scripts.
- Security_Pentester uses hacking to find vulnerabilities.
- QA_Supervisor uses testing_qa and approves (terminates).

If in Autonomous Mode:
- Master_Autonomous_Engineer sequentially uses the tools to plan, verify, view, write, audit, and test the code.

For each step, generate:
- The actor (e.g. Chief_Architect, Lead_Developer, Security_Pentester, QA_Supervisor, or Master_Autonomous_Engineer)
- The tool being called (e.g., high_thinking, hacking, coding_builder, testing_qa, none)
- The input to the tool (e.g. description of problem or file path)
- The dialogue/text explaining what is happening
- The output of the tool (e.g. simulated code snippets, analysis reports, vulnerability scan results, test results). Make it very detailed and realistic!

Format your response as a strict JSON array. Each element in the array is an object with this structure:
{
  "actor": "string (name of agent)",
  "tool": "string (tool name or 'none')",
  "toolInput": "string (or undefined)",
  "dialogue": "string (the agent's spoken thoughts or explanation)",
  "toolOutput": "string (the simulated result or code or report generated)"
}

Do not include any markdown formatting or surrounding text other than the raw JSON array. Start with [ and end with ].
`;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: simulationPrompt,
      config: {
        responseMimeType: "application/json",
      },
    });

    const parsedLogs = JSON.parse(response.text.trim());
    res.json({
      success: true,
      logs: parsedLogs,
    });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// ZIP Generator for Agent Templates & Scripts
app.get("/api/templates/download", (req, res) => {
  // Return the main templates as JSON so the browser can construct a file download
  // or a simulated zip, preserving high utility
  const templates = {
    orchestrator: `from autogen_agentchat.teams import SelectorGroupChat
from autogen_agentchat.conditions import TextMentionTermination
# Configured for roc-otoweb Agent Orchestra
# Chief_Architect, Lead_Developer, Security_Pentester, QA_Supervisor
`,
    autonomous: `# Master Autonomous Project Engineer
# Equipped with 6 powerful tools
`,
    tools: `# 1. HIGH THINKING (Deep Reasoning)
# 2. GROUNDING (Fact-Checking)
# 3. VIEWING (AST Inspector)
# 4. HACKING (Security Pentest)
# 5. CODING BUILDER (File Writer)
# 6. TESTING QA (Automation Test)
`,
  };
  res.json(templates);
});

// Vite Setup / Production serving
const distPath = path.join(process.cwd(), "dist");

if (process.env.NODE_ENV !== "production") {
  createViteServer({
    server: { middlewareMode: true },
    appType: "spa",
  }).then((vite) => {
    app.use(vite.middlewares);
    app.listen(PORT, "0.0.0.0", () => {
      console.log(`Server running on http://0.0.0.0:${PORT}`);
    });
  });
} else {
  app.use(express.static(distPath));
  app.get("*", (req, res) => {
    res.sendFile(path.join(distPath, "index.html"));
  });
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running in production on port ${PORT}`);
  });
}
