# Security Specification - roc-otoweb

## Data Invariants
1.  **Chats**:
    -   Must have `text`, `userId`, `userName`, `timestamp`.
    -   `userId` must match the authenticated user's UID.
    -   `text` must be <= 500 characters.
    -   `chats` are append-only; no updates or deletes allowed for regular users.
2.  **Configs**:
    -   Must be owned by the user (document ID = user UID).
    -   Must have `updatedAt`.
    -   Only the owner can read or write their own config.

## The "Dirty Dozen" Payloads

### Chats
1.  **Identity Spoofing**: Creating a chat with `userId` different from `request.auth.uid`.
2.  **Resource Poisoning**: Creating a chat with `text` > 500 characters.
3.  **State Shortcutting**: Attempting to update an existing chat message.
4.  **Malicious Deletion**: Attempting to delete a chat message.
5.  **Anonymity Violation**: Creating a chat without being signed in.

### Configs
6.  **Privilege Escalation**: Attempting to read another user's config document.
7.  **Unauthorized Creation**: Creating a config for another user UID.
8.  **Validation Bypass**: Writing a config without `updatedAt`.
9.  **Type Poisoning**: Writing `updatedAt` as a boolean instead of a string.
10. **Ghost Field Injection**: Adding an unrequested field like `isAdmin: true` to the config.
11. **Shadow Update**: Updating only a few fields while removing required ones (if not using merge correctly, though rules should protect the shape).
12. **Denial of Wallet**: Injected 1MB strings into any field.

## Security Audit Plan
-   Verify all read/write operations require authentication (except `chats` read).
-   Verify `isOwner` check for all `configs` operations.
-   Verify `isValidChat` and `isValidConfig` are called on all writes.
-   Verify no blanket reads on `configs`.
