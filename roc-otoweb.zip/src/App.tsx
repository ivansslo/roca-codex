import React, { useState, useEffect } from "react";
import { 
  Shield, 
  ShieldAlert, 
  Settings, 
  Bot, 
  Terminal, 
  Sparkles, 
  Code, 
  Cpu, 
  FolderDown, 
  UploadCloud, 
  RefreshCw, 
  ExternalLink, 
  Search, 
  MapPin, 
  Image as ImageIcon, 
  User as UserIcon, 
  Check, 
  AlertTriangle, 
  Send, 
  Clock, 
  Eye, 
  EyeOff, 
  Layers, 
  Lock
} from "lucide-react";
import { AppConfig, Message, AgentLog } from "./types";
import { onAuthStateChanged, User } from "firebase/auth";
import { collection, query, orderBy, limit, onSnapshot, addDoc, doc, setDoc, getDoc } from "firebase/firestore";
import { auth, db, signInWithGoogle, logout } from "./firebase";

enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  }
}

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData?.map(provider => ({
        providerId: provider.providerId,
        email: provider.email,
      })) || []
    },
    operationType,
    path
  }
  console.error('Firestore Error: ', JSON.stringify(errInfo));
}

export default function App() {
  // Navigation / Tabs
  const [activeTab, setActiveTab] = useState<"orchestra" | "gemini" | "workspace" | "settings">("orchestra");
  
  // Privacy Mode ("Aktifkan mode privasi anda")
  const [privacyMode, setPrivacyMode] = useState(false);

  // App Config / Secrets
  const [config, setConfig] = useState<AppConfig>({
    GEMINI_API_KEY: "",
    FIREBASE_PROJECT_ID: "planning-with-ai-36675",
    FIREBASE_API_KEY: "AIzaSyAPH8DG8Ji6Zjcid3s6qtnU9J8qBKGrpOQ",
    ORACLE_VM_IP: "161.118.253.28",
    PRIVACY_MODE: false
  });
  
  const [configStatus, setConfigStatus] = useState<string | null>(null);

  // Clock
  const [timeStr, setTimeStr] = useState<string>("");

  // VM Status
  const [vmStatus, setVmStatus] = useState<any>(null);
  const [probingVM, setProbingVM] = useState(false);

  // Multi-Agent Orchestra Simulation States
  const [orchestraPrompt, setOrchestraPrompt] = useState("Membangun microservice payment gateway python3 dengan integrasi Stripe, handle double-spending race conditions, dan auto-audit OWASP top-10");
  const [autonomousMode, setAutonomousMode] = useState(false);
  const [runningOrchestra, setRunningOrchestra] = useState(false);
  const [orchestraLogs, setOrchestraLogs] = useState<AgentLog[]>([]);
  const [selectedLogIndex, setSelectedLogIndex] = useState<number | null>(null);

  // Gemini Playground States
  const [textPrompt, setTextPrompt] = useState("Berikan rekomendasi setup VM robust dengan load balancer Cloudflare dan reverse proxy Nginx untuk microservice.");
  const [useHighThinking, setUseHighThinking] = useState(true);
  const [textModel, setTextModel] = useState("gemini-3.5-flash");
  const [textOutput, setTextOutput] = useState("");
  const [loadingText, setLoadingText] = useState(false);

  // Image Generation States
  const [imgPrompt, setImgPrompt] = useState("Minimalist logo of a glowing neon speed cyber-cat holding a wrench, dark background, vector art");
  const [aspectRatio, setAspectRatio] = useState("1:1");
  const [imgQuality, setImgQuality] = useState("standard");
  const [generatedImg, setGeneratedImg] = useState("");
  const [generatingImg, setGeneratingImg] = useState(false);

  // Image Analyzer States
  const [analysisImage, setAnalysisImage] = useState<string | null>(null);
  const [analysisPrompt, setAnalysisPrompt] = useState("Jelaskan detail dari gambar diagram / arsitektur ini.");
  const [analysisOutput, setAnalysisOutput] = useState("");
  const [analyzingImage, setAnalyzingImage] = useState(false);

  // Grounding States
  const [groundingPrompt, setGroundingPrompt] = useState("Berapa latency koneksi internet fiber optik Biznet vs Indihome di Surabaya terbaru tahun ini?");
  const [groundingType, setGroundingType] = useState<"search" | "maps">("search");
  const [groundingOutput, setGroundingOutput] = useState("");
  const [groundingSources, setGroundingSources] = useState<any[]>([]);
  const [loadingGrounding, setLoadingGrounding] = useState(false);

  // Chatbot state
  const [chatMessage, setChatMessage] = useState("");
  const [chatRole, setChatRole] = useState("You are Chief Technical Architect. Help me solve complex microservice designs.");
  const [chatHistory, setChatHistory] = useState<Message[]>([
    { id: "1", sender: "model", text: "Halo, saya Hermes AI Architect. Siap mengotomatisasi blueprint dan models Anda.", timestamp: new Date().toLocaleTimeString() }
  ]);
  const [sendingChat, setSendingChat] = useState(false);

  // Firestore Viewer states
  const [firestoreMsgs, setFirestoreMsgs] = useState<any[]>([]);
  const [newFbMsg, setNewFbMsg] = useState("");
  const [loadingFb, setLoadingFb] = useState(false);

  // Shared Global Auth State
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [accessToken, setAccessToken] = useState<string | null>(null);

  // Global Auth Handlers
  const handleGlobalSignIn = async () => {
    try {
      const result = await signInWithGoogle();
      setCurrentUser(result.user);
      setAccessToken(result.token);
    } catch (err: any) {
      console.error("Sign-in failed", err);
    }
  };

  const handleGlobalSignOut = async () => {
    try {
      await logout();
      setCurrentUser(null);
      setAccessToken(null);
    } catch (err: any) {
      console.error("Sign-out failed", err);
    }
  };

  // Load clock, initial configs, and Firebase Auth / Firestore subscriptions
  useEffect(() => {
    const timer = setInterval(() => {
      setTimeStr(new Date().toLocaleString("id-ID"));
    }, 1000);

    fetchConfig();
    probeVM();

    // Listen to Auth State Changed
    const unsubscribeAuth = onAuthStateChanged(auth, (user) => {
      if (user) {
        setCurrentUser(user);
      } else {
        setCurrentUser(null);
        setAccessToken(null);
      }
    });

    return () => {
      clearInterval(timer);
      unsubscribeAuth();
    };
  }, []);

  // Auto-save config to Firestore
  useEffect(() => {
    if (!currentUser) return;
    
    const saveToFirestore = async () => {
      const path = `configs/${currentUser.uid}`;
      try {
        await setDoc(doc(db, "configs", currentUser.uid), {
          ...config,
          updatedAt: new Date().toISOString()
        }, { merge: true });
      } catch (err) {
        handleFirestoreError(err, OperationType.WRITE, path);
      }
    };

    const timeout = setTimeout(saveToFirestore, 2000); // Debounce 2s
    return () => clearTimeout(timeout);
  }, [config, currentUser]);

  // Load config from Firestore on sign-in
  useEffect(() => {
    if (currentUser) {
      const loadFromFirestore = async () => {
        const path = `configs/${currentUser.uid}`;
        try {
          const docSnap = await getDoc(doc(db, "configs", currentUser.uid));
          if (docSnap.exists()) {
            const data = docSnap.data() as AppConfig;
            setConfig(prev => ({ ...prev, ...data }));
          }
        } catch (err) {
          handleFirestoreError(err, OperationType.GET, path);
        }
      };
      loadFromFirestore();
    }
  }, [currentUser]);

  // Listen to Firestore real-time chats
  useEffect(() => {
    const chatsQuery = query(
      collection(db, "chats"),
      orderBy("timestamp", "desc"),
      limit(20)
    );

    const unsubscribeChats = onSnapshot(chatsQuery, (snapshot) => {
      const msgs: any[] = [];
      snapshot.forEach((doc) => {
        msgs.push({ id: doc.id, ...doc.data() });
      });
      // Sort oldest to newest to display sequentially
      setFirestoreMsgs(msgs.reverse());
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, "chats");
    });

    return () => unsubscribeChats();
  }, []);

  const handleSendFirestoreMsg = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newFbMsg.trim() || !currentUser) return;
    setLoadingFb(true);
    const path = "chats";
    try {
      await addDoc(collection(db, path), {
        text: newFbMsg,
        userId: currentUser.uid,
        userName: currentUser.displayName || currentUser.email || "Developer",
        timestamp: new Date().toISOString()
      });
      setNewFbMsg("");
    } catch (err: any) {
      handleFirestoreError(err, OperationType.CREATE, path);
    } finally {
      setLoadingFb(false);
    }
  };

  const fetchConfig = async () => {
    try {
      const res = await fetch("/api/config");
      if (res.ok) {
        const data = await res.json();
        setConfig(data);
        setPrivacyMode(data.PRIVACY_MODE);
      }
    } catch (e) {
      console.error("Failed to load config.");
    }
  };

  const handleSaveConfig = async (e: React.FormEvent) => {
    e.preventDefault();
    setConfigStatus("Saving...");
    try {
      const res = await fetch("/api/config", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...config,
          PRIVACY_MODE: privacyMode
        }),
      });
      if (res.ok) {
        setConfigStatus("Configuration saved successfully.");
        setTimeout(() => setConfigStatus(null), 3000);
      } else {
        setConfigStatus("Failed to save.");
      }
    } catch (e: any) {
      setConfigStatus("Error: " + e.message);
    }
  };

  const probeVM = async () => {
    setProbingVM(true);
    try {
      const res = await fetch("/api/vm/status");
      if (res.ok) {
        const data = await res.json();
        setVmStatus(data);
      }
    } catch (e) {
      console.error("VM Probe failed.");
    } finally {
      setProbingVM(false);
    }
  };

  // Run Multi-Agent simulation
  const runOrchestraSimulation = async () => {
    if (!orchestraPrompt.trim()) return;
    setRunningOrchestra(true);
    setOrchestraLogs([]);
    setSelectedLogIndex(null);

    try {
      const res = await fetch("/api/orchestra/run", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          prompt: orchestraPrompt,
          autonomousMode,
        }),
      });

      if (res.ok) {
        const data = await res.json();
        if (data.success && data.logs) {
          // Simulate dynamic typing / arrival of logs for premium experience
          let currentIdx = 0;
          const interval = setInterval(() => {
            if (currentIdx < data.logs.length) {
              setOrchestraLogs(prev => [...prev, data.logs[currentIdx]]);
              setSelectedLogIndex(currentIdx);
              currentIdx++;
            } else {
              clearInterval(interval);
              setRunningOrchestra(false);
            }
          }, 1500);
        }
      } else {
        throw new Error("Server error while executing orchestra.");
      }
    } catch (e: any) {
      setRunningOrchestra(false);
      alert(e.message || "Execution failed.");
    }
  };

  // Run Text Gen
  const runTextGen = async () => {
    if (!textPrompt.trim()) return;
    setLoadingText(true);
    setTextOutput("");
    try {
      const res = await fetch("/api/gemini/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          prompt: textPrompt,
          model: textModel,
          useHighThinking,
        }),
      });
      if (res.ok) {
        const data = await res.json();
        setTextOutput(data.text);
      } else {
        throw new Error("Failed to generate response.");
      }
    } catch (err: any) {
      setTextOutput("Error: " + err.message);
    } finally {
      setLoadingText(false);
    }
  };

  // Run Image Gen
  const runImageGen = async () => {
    if (!imgPrompt.trim()) return;
    setGeneratingImg(true);
    setGeneratedImg("");
    try {
      const res = await fetch("/api/gemini/generate-image", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          prompt: imgPrompt,
          aspectRatio,
          quality: imgQuality,
        }),
      });
      if (res.ok) {
        const data = await res.json();
        if (data.imageUrl) {
          setGeneratedImg(data.imageUrl);
        } else {
          throw new Error("No image data returned from Gemini.");
        }
      } else {
        throw new Error("Failed to generate image.");
      }
    } catch (err: any) {
      alert("Image generation failed: " + err.message);
    } finally {
      setGeneratingImg(false);
    }
  };

  // Image Upload & Analysis handler
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setAnalysisImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const runImageAnalysis = async () => {
    if (!analysisImage) return;
    setAnalyzingImage(true);
    setAnalysisOutput("");
    try {
      const res = await fetch("/api/gemini/analyze-image", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          imageBase64: analysisImage,
          prompt: analysisPrompt,
        }),
      });
      if (res.ok) {
        const data = await res.json();
        setAnalysisOutput(data.text);
      } else {
        throw new Error("Failed to analyze image.");
      }
    } catch (err: any) {
      setAnalysisOutput("Error: " + err.message);
    } finally {
      setAnalyzingImage(false);
    }
  };

  // Grounding
  const runGrounding = async () => {
    if (!groundingPrompt.trim()) return;
    setLoadingGrounding(true);
    setGroundingOutput("");
    setGroundingSources([]);
    try {
      const res = await fetch("/api/gemini/grounding", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          prompt: groundingPrompt,
          type: groundingType,
        }),
      });
      if (res.ok) {
        const data = await res.json();
        setGroundingOutput(data.text);
        setGroundingSources(data.sources || []);
      } else {
        throw new Error("Grounding request failed.");
      }
    } catch (err: any) {
      setGroundingOutput("Error: " + err.message);
    } finally {
      setLoadingGrounding(false);
    }
  };

  // Multi-turn Chat
  const sendChatMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatMessage.trim() || sendingChat) return;

    const userMsg: Message = {
      id: Math.random().toString(),
      sender: "user",
      text: chatMessage,
      timestamp: new Date().toLocaleTimeString(),
    };

    setChatHistory(prev => [...prev, userMsg]);
    setChatMessage("");
    setSendingChat(true);

    try {
      const res = await fetch("/api/gemini/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: userMsg.text,
          history: chatHistory,
          roleInstruction: chatRole,
        }),
      });

      if (res.ok) {
        const data = await res.json();
        const modelMsg: Message = {
          id: Math.random().toString(),
          sender: "model",
          text: data.text,
          timestamp: new Date().toLocaleTimeString(),
        };
        setChatHistory(prev => [...prev, modelMsg]);
      } else {
        throw new Error("Chat session error.");
      }
    } catch (err: any) {
      const errorMsg: Message = {
        id: Math.random().toString(),
        sender: "model",
        text: "Gagal memproses pesan: " + err.message,
        timestamp: new Date().toLocaleTimeString(),
      };
      setChatHistory(prev => [...prev, errorMsg]);
    } finally {
      setSendingChat(false);
    }
  };

  // ZIP Downloader Simulator
  const handleDownloadTemplate = async () => {
    try {
      const res = await fetch("/api/templates/download");
      if (res.ok) {
        const data = await res.json();
        const jsonStr = JSON.stringify(data, null, 2);
        const blob = new Blob([jsonStr], { type: "application/json" });
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = "roc-agentsroute-config-bundle.json";
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
      }
    } catch (e) {
      alert("Gagal mengunduh bundle template.");
    }
  };

  return (
    <div className="min-h-screen bg-[#05070d] text-[#dbe4ff] font-sans antialiased relative">
      {/* Absolute Decorative Ambient Background Gradients */}
      <div className="absolute top-0 left-0 w-[500px] h-[500px] bg-cyan-500/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-10 right-10 w-[600px] h-[600px] bg-purple-500/5 rounded-full blur-3xl pointer-events-none" />

      {/* Main Container */}
      <div className="max-w-7xl mx-auto px-4 py-6 md:py-10 space-y-6 relative z-10">
        
        {/* HEADER */}
        <header className="flex flex-col md:flex-row md:items-center md:justify-between p-6 bg-[#0b1020] border border-[#1c2647] rounded-3xl gap-4 shadow-2xl relative overflow-hidden">
          {/* Subtle line background effect */}
          <div className="absolute inset-0 bg-gradient-to-r from-transparent via-[#1c2647]/20 to-transparent" />
          
          <div className="space-y-1 relative z-10">
            <div className="flex items-center gap-3">
              <span className="text-3xl animate-pulse">⚡</span>
              <div>
                <h1 className="text-xl md:text-2xl font-bold font-display tracking-tight bg-gradient-to-r from-cyan-400 via-[#a78bfa] to-purple-400 bg-clip-text text-transparent">
                  roc-otoweb
                </h1>
                <span className="text-[10px] uppercase font-mono tracking-widest bg-cyan-500/10 text-cyan-400 px-2 py-0.5 rounded-full border border-cyan-500/20">
                  Hermes v5.13.1 "Oracle"
                </span>
              </div>
            </div>
            <p className="text-xs text-[#8b98c9] max-w-2xl font-sans mt-1">
              Sistem Otomasi Arsitek &amp; Orchestrator Multi-Agen Otonom dengan integrasi model Gemini 3.1 &amp; Firestore Sync.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3 relative z-10 shrink-0">
            {/* Shared Google / Firebase Auth profile badge */}
            {currentUser ? (
              <div className="flex items-center gap-2 bg-[#05070d]/60 border border-[#1c2647] px-3.5 py-1.5 rounded-xl text-xs text-[#dbe4ff]">
                {currentUser.photoURL ? (
                  <img src={currentUser.photoURL} alt="Avatar" className="w-5 h-5 rounded-full" referrerPolicy="no-referrer" />
                ) : (
                  <div className="w-5 h-5 bg-cyan-500/20 text-cyan-400 rounded-full flex items-center justify-center text-[10px]">
                    {currentUser.displayName?.[0] || "?"}
                  </div>
                )}
                <span className="font-semibold text-[11px] truncate max-w-[120px]">
                  {privacyMode ? "Developer" : (currentUser.displayName || currentUser.email)}
                </span>
                <button
                  onClick={handleGlobalSignOut}
                  className="ml-1 text-red-400 hover:text-red-300 font-mono text-[10px] hover:underline cursor-pointer transition"
                >
                  Sign Out
                </button>
              </div>
            ) : (
              <button
                onClick={handleGlobalSignIn}
                className="flex items-center gap-2 bg-white hover:bg-gray-100 text-[#05070d] font-bold text-xs px-3.5 py-2 rounded-xl transition cursor-pointer"
              >
                <UserIcon className="w-3.5 h-3.5" />
                <span>Sign In with Firebase</span>
              </button>
            )}

            {/* Live clock with indonesian format */}
            <div className="flex items-center gap-2 bg-[#05070d]/60 border border-[#1c2647] px-3.5 py-1.5 rounded-xl font-mono text-xs text-[#8b98c9]">
              <Clock className="w-3.5 h-3.5 text-cyan-400" />
              <span>{timeStr || "Memuat..."}</span>
            </div>

            {/* Privacy Mode Toggle */}
            <button
              onClick={() => {
                const newMode = !privacyMode;
                setPrivacyMode(newMode);
                // Auto-save setting
                fetch("/api/config", {
                  method: "POST",
                  headers: { "Content-Type": "application/json" },
                  body: JSON.stringify({ PRIVACY_MODE: newMode }),
                });
              }}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition duration-300 shadow-md ${
                privacyMode 
                ? "bg-red-500/20 text-red-400 border border-red-500/40 hover:bg-red-500/30" 
                : "bg-cyan-500/10 text-cyan-400 border border-cyan-500/30 hover:bg-cyan-500/20"
              }`}
            >
              {privacyMode ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              <span>{privacyMode ? "Privacy Mode: ON" : "Privacy Mode: OFF"}</span>
            </button>
          </div>
        </header>

        {/* SYSTEM CHIPS STATUS BAR */}
        <section className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          <div className="bg-[#0b1020]/80 border border-[#1c2647] p-4 rounded-2xl flex items-center gap-3">
            <span className="w-2.5 h-2.5 bg-green-500 rounded-full shadow-[0_0_10px_#10b981]" />
            <div>
              <p className="text-[10px] text-[#8b98c9] font-mono uppercase tracking-widest">Sistem Server</p>
              <h3 className="text-xs font-bold font-mono">ONLINE</h3>
            </div>
          </div>

          <div className="bg-[#0b1020]/80 border border-[#1c2647] p-4 rounded-2xl flex items-center gap-3">
            <span className="w-2.5 h-2.5 bg-green-500 rounded-full shadow-[0_0_10px_#10b981]" />
            <div>
              <p className="text-[10px] text-[#8b98c9] font-mono uppercase tracking-widest">Oracle VM Link</p>
              <h3 className="text-xs font-bold font-mono text-cyan-400">
                {privacyMode ? "161.•••.•••.••" : (vmStatus?.ip || "161.118.253.28")}
              </h3>
            </div>
          </div>

          <div className="bg-[#0b1020]/80 border border-[#1c2647] p-4 rounded-2xl flex items-center gap-3">
            <span className="w-2.5 h-2.5 bg-purple-500 rounded-full shadow-[0_0_10px_#a78bfa]" />
            <div>
              <p className="text-[10px] text-[#8b98c9] font-mono uppercase tracking-widest">Firebase Project</p>
              <h3 className="text-xs font-bold font-mono text-purple-400">
                {privacyMode ? "•••••••••••••" : "planning-with-ai-36675"}
              </h3>
            </div>
          </div>

          <div className="bg-[#0b1020]/80 border border-[#1c2647] p-4 rounded-2xl flex items-center gap-3">
            <span className="w-2.5 h-2.5 bg-cyan-500 rounded-full shadow-[0_0_10px_#22d3ee]" />
            <div>
              <p className="text-[10px] text-[#8b98c9] font-mono uppercase tracking-widest">Firestore Sync</p>
              <h3 className="text-xs font-bold font-mono text-[#dbe4ff]">Live Auto-Save</h3>
            </div>
          </div>
        </section>

        {/* NAVIGATION TABS */}
        <nav className="flex items-center gap-2 border-b border-[#1c2647] pb-2">
          <button
            onClick={() => setActiveTab("orchestra")}
            className={`flex items-center gap-2 px-4 py-2.5 text-sm font-semibold border-b-2 transition duration-200 ${
              activeTab === "orchestra"
              ? "border-cyan-400 text-cyan-400 bg-cyan-500/5 rounded-t-xl"
              : "border-transparent text-[#8b98c9] hover:text-[#txt]"
            }`}
          >
            <Bot className="w-4 h-4" />
            <span>Agent Orchestra</span>
          </button>

          <button
            onClick={() => setActiveTab("gemini")}
            className={`flex items-center gap-2 px-4 py-2.5 text-sm font-semibold border-b-2 transition duration-200 ${
              activeTab === "gemini"
              ? "border-cyan-400 text-cyan-400 bg-cyan-500/5 rounded-t-xl"
              : "border-transparent text-[#8b98c9] hover:text-[#txt]"
            }`}
          >
            <Sparkles className="w-4 h-4" />
            <span>Gemini Hub</span>
          </button>

          <button
            onClick={() => setActiveTab("workspace")}
            className={`flex items-center gap-2 px-4 py-2.5 text-sm font-semibold border-b-2 transition duration-200 ${
              activeTab === "workspace"
              ? "border-cyan-400 text-cyan-400 bg-cyan-500/5 rounded-t-xl"
              : "border-transparent text-[#8b98c9] hover:text-[#txt]"
            }`}
          >
            <Terminal className="w-4 h-4" />
            <span>Firestore Live</span>
          </button>

          <button
            onClick={() => setActiveTab("settings")}
            className={`flex items-center gap-2 px-4 py-2.5 text-sm font-semibold border-b-2 transition duration-200 ${
              activeTab === "settings"
              ? "border-cyan-400 text-cyan-400 bg-cyan-500/5 rounded-t-xl"
              : "border-transparent text-[#8b98c9] hover:text-[#txt]"
            }`}
          >
            <Settings className="w-4 h-4" />
            <span>Settings &amp; Secrets</span>
          </button>
        </nav>

        {/* TAB CONTENTS */}
        <main className="min-h-[500px]">
          
          {/* TAB 1: AGENT ORCHESTRA SIMULATOR */}
          {activeTab === "orchestra" && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 animate-fade-in">
              {/* Left Configuration Panel */}
              <div className="lg:col-span-4 space-y-4">
                <div className="bg-[#0b1020] border border-[#1c2647] rounded-2xl p-5 space-y-4 shadow-xl">
                  <div className="flex items-center gap-2 text-cyan-400 font-display font-semibold mb-1">
                    <Terminal className="w-5 h-5" />
                    <h2>Launcher Control</h2>
                  </div>

                  <div className="space-y-1">
                    <label className="block text-xs text-[#8b98c9] font-mono uppercase tracking-wider">Prompt / Task Description</label>
                    <textarea
                      value={orchestraPrompt}
                      onChange={(e) => setOrchestraPrompt(e.target.value)}
                      rows={5}
                      className="w-full bg-[#05070d] border border-[#1c2647] rounded-xl text-xs text-[#dbe4ff] p-3 outline-none focus:border-cyan-500 font-mono"
                      placeholder="Masukkan tugas yang ingin di-solve oleh agent..."
                    />
                  </div>

                  {/* Mode Selector */}
                  <div className="space-y-2">
                    <label className="block text-xs text-[#8b98c9] font-mono uppercase tracking-wider">Mode Operasional</label>
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        onClick={() => setAutonomousMode(false)}
                        className={`p-3 rounded-xl border text-xs font-bold transition flex flex-col items-center gap-1.5 ${
                          !autonomousMode
                          ? "bg-cyan-500/15 border-cyan-400 text-cyan-400"
                          : "bg-[#05070d]/60 border-[#1c2647] text-[#8b98c9] hover:text-[#txt]"
                        }`}
                      >
                        <Layers className="w-4 h-4" />
                        <span>Team Orchestra</span>
                      </button>

                      <button
                        onClick={() => setAutonomousMode(true)}
                        className={`p-3 rounded-xl border text-xs font-bold transition flex flex-col items-center gap-1.5 ${
                          autonomousMode
                          ? "bg-purple-500/15 border-purple-400 text-purple-400"
                          : "bg-[#05070d]/60 border-[#1c2647] text-[#8b98c9] hover:text-[#txt]"
                        }`}
                      >
                        <Cpu className="w-4 h-4" />
                        <span>Master Autonomous</span>
                      </button>
                    </div>
                  </div>

                  <div className="pt-2">
                    <button
                      onClick={runOrchestraSimulation}
                      disabled={runningOrchestra || !orchestraPrompt.trim()}
                      className="w-full bg-cyan-500 hover:bg-cyan-600 disabled:opacity-50 text-[#04121a] font-bold py-3 px-4 rounded-xl flex items-center justify-center gap-2 transition shadow-lg shadow-cyan-500/10 active:scale-95 cursor-pointer"
                    >
                      {runningOrchestra ? (
                        <>
                          <RefreshCw className="w-4 h-4 animate-spin" />
                          <span>Simulasi Berjalan...</span>
                        </>
                      ) : (
                        <>
                          <Bot className="w-4 h-4" />
                          <span>Launch Agent System</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>

                {/* Templates Bundle Zip Downloader Card */}
                <div className="bg-[#0b1020] border border-[#1c2647] rounded-2xl p-5 space-y-4 shadow-xl relative overflow-hidden">
                  <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-br from-purple-500/10 to-transparent blur-2xl" />
                  <div className="flex items-center gap-2 text-purple-400 font-display font-semibold">
                    <FolderDown className="w-5 h-5" />
                    <h2>Templates &amp; Scripts</h2>
                  </div>
                  <p className="text-xs text-[#8b98c9] leading-relaxed">
                    Unduh file template ZIP utama dan blueprint script Multi-Agent Autogen yang matang untuk diimplementasikan secara instan ke local Termux atau container Anda.
                  </p>
                  <button
                    onClick={handleDownloadTemplate}
                    className="w-full bg-purple-500/20 hover:bg-purple-500/30 text-purple-300 font-bold py-2.5 px-4 rounded-xl flex items-center justify-center gap-2 border border-purple-500/30 transition text-xs"
                  >
                    <FolderDown className="w-4 h-4" />
                    <span>Download Script Bundle</span>
                  </button>
                </div>
              </div>

              {/* Right Output Console and Logs */}
              <div className="lg:col-span-8 flex flex-col space-y-4">
                <div className="bg-[#05070d] border border-[#1c2647] rounded-2xl flex-1 flex flex-col overflow-hidden min-h-[500px] shadow-2xl relative">
                  {/* Console Header */}
                  <div className="bg-[#0b1020] border-b border-[#1c2647] px-4 py-3 flex items-center justify-between shrink-0">
                    <div className="flex items-center gap-2">
                      <span className="flex gap-1.5">
                        <span className="w-3 h-3 rounded-full bg-red-500/70" />
                        <span className="w-3 h-3 rounded-full bg-amber-500/70" />
                        <span className="w-3 h-3 rounded-full bg-green-500/70" />
                      </span>
                      <span className="text-xs text-[#8b98c9] font-mono ml-2">agents-execution-console.log</span>
                    </div>
                    {runningOrchestra && (
                      <span className="text-[10px] text-cyan-400 font-mono animate-pulse bg-cyan-500/10 px-2 py-0.5 rounded border border-cyan-500/20">
                        PROCESSING TRACE
                      </span>
                    )}
                  </div>

                  {/* Console Body */}
                  <div className="flex-1 p-4 overflow-y-auto font-mono text-xs space-y-4 max-h-[550px]">
                    {orchestraLogs.length === 0 ? (
                      <div className="flex flex-col items-center justify-center h-full text-center space-y-3 py-20 text-[#8b98c9]">
                        <Bot className="w-12 h-12 text-[#1c2647] animate-bounce" />
                        <div className="space-y-1">
                          <p className="font-semibold text-sm">Menunggu Inisialisasi Agent</p>
                          <p className="text-xs">Tekan tombol Launch di panel kiri untuk mensimulasikan sistem multi-agen otonom.</p>
                        </div>
                      </div>
                    ) : (
                      <div className="space-y-3">
                        {orchestraLogs.map((log, index) => {
                          const isArchitect = log.actor?.includes("Architect");
                          const isDeveloper = log.actor?.includes("Developer");
                          const isPentester = log.actor?.includes("Pentester");
                          const isQA = log.actor?.includes("QA") || log.actor?.includes("Supervisor");
                          
                          let actorColor = "text-cyan-400";
                          let bgActor = "bg-cyan-500/5 border-cyan-500/20";
                          if (isDeveloper) { actorColor = "text-green-400"; bgActor = "bg-green-500/5 border-green-500/20"; }
                          else if (isPentester) { actorColor = "text-red-400"; bgActor = "bg-red-500/5 border-red-500/20"; }
                          else if (isQA) { actorColor = "text-purple-400"; bgActor = "bg-purple-500/5 border-purple-500/20"; }

                          return (
                            <div 
                              key={index} 
                              onClick={() => setSelectedLogIndex(index)}
                              className={`p-3.5 border rounded-xl cursor-pointer transition ${bgActor} ${
                                selectedLogIndex === index 
                                ? "ring-1 ring-cyan-400 border-cyan-400/40" 
                                : "hover:border-[#1c2647] hover:bg-[#0b1020]/30"
                              }`}
                            >
                              <div className="flex items-center justify-between mb-1">
                                <span className={`font-bold ${actorColor} text-xs`}>
                                  [{log.actor?.toUpperCase()}]
                                </span>
                                {log.tool && log.tool !== "none" && (
                                  <span className="text-[10px] bg-[#05070d]/90 border border-cyan-500/20 text-cyan-400 px-2 py-0.5 rounded-full">
                                    tool: {log.tool}
                                  </span>
                                )}
                              </div>
                              <p className="text-[#dbe4ff] leading-relaxed text-xs">
                                {log.dialogue}
                              </p>
                              {log.toolInput && (
                                <div className="mt-2 text-[10px] bg-[#05070d]/70 text-[#8b98c9] p-1.5 rounded border border-[#1c2647]">
                                  <span className="font-bold text-[#dbe4ff]">Input:</span> {log.toolInput}
                                </div>
                              )}
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </div>
                </div>

                {/* Log / Code Tool Output inspector detail panel */}
                {selectedLogIndex !== null && orchestraLogs[selectedLogIndex] && (
                  <div className="bg-[#0b1020] border border-[#1c2647] rounded-2xl p-5 space-y-3 shadow-xl animate-slide-up font-mono">
                    <div className="flex items-center justify-between border-b border-[#1c2647] pb-2 mb-2">
                      <span className="text-xs font-bold text-cyan-400">
                        Tool Output Inspector — [{orchestraLogs[selectedLogIndex].tool?.toUpperCase() || "DIALOGUE"}]
                      </span>
                      <button 
                        onClick={() => setSelectedLogIndex(null)}
                        className="text-xs text-[#8b98c9] hover:text-[#txt]"
                      >
                        Tutup
                      </button>
                    </div>

                    {orchestraLogs[selectedLogIndex].toolOutput ? (
                      <div className="bg-[#05070d] border border-[#1c2647] rounded-xl p-4 overflow-x-auto text-[11px] text-green-400 whitespace-pre">
                        <code>{orchestraLogs[selectedLogIndex].toolOutput}</code>
                      </div>
                    ) : (
                      <p className="text-xs text-[#8b98c9]">Pesan dialog ini tidak menghasilkan output eksekusi tool terpisah.</p>
                    )}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB 2: GEMINI PLAYGROUND */}
          {activeTab === "gemini" && (
            <div className="space-y-6 animate-fade-in">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                
                {/* Text Generation / High Thinking (Pro) vs Low Latency (Flash) */}
                <div className="bg-[#0b1020] border border-[#1c2647] rounded-2xl p-6 space-y-4 shadow-xl">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Sparkles className="text-cyan-400 w-5 h-5" />
                      <h2 className="text-md font-bold tracking-tight">Standard &amp; High-Thinking Gen</h2>
                    </div>
                    {useHighThinking && (
                      <span className="text-[10px] bg-cyan-500/10 text-cyan-400 px-2 py-0.5 rounded font-bold uppercase border border-cyan-500/20">
                        Thinking Mode Active
                      </span>
                    )}
                  </div>

                  <div className="space-y-1">
                    <label className="block text-xs text-[#8b98c9] font-mono">Prompt</label>
                    <textarea
                      value={textPrompt}
                      onChange={(e) => setTextPrompt(e.target.value)}
                      rows={3}
                      className="w-full bg-[#05070d] border border-[#1c2647] rounded-xl text-xs text-[#dbe4ff] p-3 outline-none focus:border-cyan-500"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs text-[#8b98c9] font-mono mb-1">Model Selection</label>
                      <select
                        value={textModel}
                        onChange={(e) => {
                          setTextModel(e.target.value);
                          if (e.target.value === "gemini-3.1-flash-lite") {
                            setUseHighThinking(false);
                          }
                        }}
                        className="w-full bg-[#05070d] border border-[#1c2647] rounded-xl text-xs text-[#txt] p-2 outline-none focus:border-cyan-500"
                      >
                        <option value="gemini-3.5-flash">gemini-3.5-flash (General)</option>
                        <option value="gemini-3.1-pro-preview">gemini-3.1-pro-preview (Complex)</option>
                        <option value="gemini-3.1-flash-lite">gemini-3.1-flash-lite (Fast)</option>
                      </select>
                    </div>

                    <div className="flex flex-col justify-end">
                      <button
                        onClick={() => {
                          if (textModel !== "gemini-3.1-flash-lite") {
                            setUseHighThinking(!useHighThinking);
                          }
                        }}
                        disabled={textModel === "gemini-3.1-flash-lite"}
                        className={`w-full py-2 px-3 rounded-xl border text-xs font-bold transition flex items-center justify-center gap-2 ${
                          useHighThinking 
                          ? "bg-cyan-500/15 border-cyan-400 text-cyan-400" 
                          : "bg-[#05070d] border-[#1c2647] text-[#8b98c9] hover:text-[#txt] disabled:opacity-50"
                        }`}
                      >
                        <Cpu className="w-4 h-4" />
                        <span>Enable High Thinking</span>
                      </button>
                    </div>
                  </div>

                  <button
                    onClick={runTextGen}
                    disabled={loadingText || !textPrompt.trim()}
                    className="w-full bg-cyan-500 hover:bg-cyan-600 disabled:opacity-50 text-[#04121a] font-bold py-2.5 px-4 rounded-xl flex items-center justify-center gap-2 transition cursor-pointer"
                  >
                    {loadingText ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
                    <span>{loadingText ? "Generating..." : "Generate Content"}</span>
                  </button>

                  {textOutput && (
                    <div className="p-4 bg-[#05070d] border border-[#1c2647] rounded-xl space-y-1">
                      <div className="text-[10px] text-[#8b98c9] font-mono border-b border-[#1c2647] pb-1 mb-2">OUTPUT FROM GEMINI</div>
                      <p className="text-xs text-[#dbe4ff] leading-relaxed whitespace-pre-wrap">{textOutput}</p>
                    </div>
                  )}
                </div>

                {/* Multi-turn Chatbot with custom Roles */}
                <div className="bg-[#0b1020] border border-[#1c2647] rounded-2xl p-6 space-y-4 shadow-xl flex flex-col justify-between">
                  <div>
                    <div className="flex items-center gap-2 text-cyan-400 mb-3">
                      <Bot className="w-5 h-5" />
                      <h2 className="text-md font-bold tracking-tight">Gemini Chatbot (Multi-Turn)</h2>
                    </div>

                    <div className="space-y-1.5">
                      <label className="block text-[10px] text-[#8b98c9] font-mono">System Instruction / Role</label>
                      <input
                        type="text"
                        value={chatRole}
                        onChange={(e) => setChatRole(e.target.value)}
                        className="w-full bg-[#05070d] border border-[#1c2647] rounded-xl text-xs text-[#dbe4ff] p-2.5 outline-none focus:border-cyan-500"
                      />
                    </div>

                    {/* Chat History Container */}
                    <div className="mt-4 border border-[#1c2647] rounded-xl p-3 bg-[#05070d]/60 h-48 overflow-y-auto space-y-3 scrollbar">
                      {chatHistory.map((msg) => (
                        <div 
                          key={msg.id} 
                          className={`flex flex-col max-w-[85%] ${
                            msg.sender === "user" ? "ml-auto items-end" : "mr-auto items-start"
                          }`}
                        >
                          <div className={`p-2.5 rounded-2xl text-xs leading-relaxed ${
                            msg.sender === "user" 
                            ? "bg-cyan-500 text-[#04121a] font-medium rounded-tr-none" 
                            : "bg-[#0b1020] border border-[#1c2647] text-[#dbe4ff] rounded-tl-none"
                          }`}>
                            <p>{privacyMode && msg.sender === "user" ? "••••••••••" : msg.text}</p>
                          </div>
                          <span className="text-[9px] text-[#8b98c9] font-mono mt-0.5">{msg.timestamp}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <form onSubmit={sendChatMessage} className="flex gap-2 mt-4 shrink-0">
                    <input
                      type="text"
                      value={chatMessage}
                      onChange={(e) => setChatMessage(e.target.value)}
                      placeholder="Masukkan pesan obrolan..."
                      className="flex-1 bg-[#05070d] border border-[#1c2647] rounded-xl text-xs text-[#dbe4ff] p-3 outline-none focus:border-cyan-500"
                    />
                    <button
                      type="submit"
                      disabled={sendingChat || !chatMessage.trim()}
                      className="bg-cyan-500 hover:bg-cyan-600 disabled:opacity-50 text-[#04121a] font-bold px-4 rounded-xl flex items-center justify-center transition cursor-pointer"
                    >
                      <Send className="w-4 h-4" />
                    </button>
                  </form>
                </div>
              </div>

              {/* Image Gen & Upload/Analysis Row */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                
                {/* Image Generation & Aspect Ratio Control */}
                <div className="bg-[#0b1020] border border-[#1c2647] rounded-2xl p-6 space-y-4 shadow-xl">
                  <div className="flex items-center gap-2 text-cyan-400">
                    <ImageIcon className="w-5 h-5" />
                    <h2 className="text-md font-bold tracking-tight">Create &amp; Edit Images</h2>
                  </div>

                  <div className="space-y-1">
                    <label className="block text-xs text-[#8b98c9] font-mono">Prompt</label>
                    <input
                      type="text"
                      value={imgPrompt}
                      onChange={(e) => setImgPrompt(e.target.value)}
                      className="w-full bg-[#05070d] border border-[#1c2647] rounded-xl text-xs text-[#dbe4ff] p-3 outline-none focus:border-cyan-500"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs text-[#8b98c9] font-mono mb-1">Aspect Ratio</label>
                      <select
                        value={aspectRatio}
                        onChange={(e) => setAspectRatio(e.target.value)}
                        className="w-full bg-[#05070d] border border-[#1c2647] rounded-xl text-xs text-[#txt] p-2 outline-none focus:border-cyan-500"
                      >
                        <option value="1:1">1:1 (Square)</option>
                        <option value="2:3">2:3 (Portrait)</option>
                        <option value="3:2">3:2 (Landscape)</option>
                        <option value="3:4">3:4 (Portrait)</option>
                        <option value="4:3">4:3 (Landscape)</option>
                        <option value="9:16">9:16 (Tall)</option>
                        <option value="16:9">16:9 (Wide)</option>
                        <option value="21:9">21:9 (Cinematic)</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs text-[#8b98c9] font-mono mb-1">Quality Profile</label>
                      <select
                        value={imgQuality}
                        onChange={(e) => setImgQuality(e.target.value)}
                        className="w-full bg-[#05070d] border border-[#1c2647] rounded-xl text-xs text-[#txt] p-2 outline-none focus:border-cyan-500"
                      >
                        <option value="standard">Standard (Fast)</option>
                        <option value="high">Studio High Quality (Pro)</option>
                      </select>
                    </div>
                  </div>

                  <button
                    onClick={runImageGen}
                    disabled={generatingImg || !imgPrompt.trim()}
                    className="w-full bg-cyan-500 hover:bg-cyan-600 disabled:opacity-50 text-[#04121a] font-bold py-2.5 px-4 rounded-xl flex items-center justify-center gap-2 transition cursor-pointer"
                  >
                    {generatingImg ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
                    <span>{generatingImg ? "Generating Asset..." : "Generate Image"}</span>
                  </button>

                  {generatedImg && (
                    <div className="mt-4 flex flex-col items-center border border-[#1c2647] p-3 rounded-xl bg-[#05070d] gap-2">
                      <img src={generatedImg} alt="Generated" className="max-w-full rounded-lg max-h-60 object-contain shadow-xl" />
                      <a 
                        href={generatedImg} 
                        download="gemini-generated-art.png"
                        className="text-xs text-cyan-400 font-mono hover:underline flex items-center gap-1"
                      >
                        Download Image
                      </a>
                    </div>
                  )}
                </div>

                {/* Image Upload & Analysis */}
                <div className="bg-[#0b1020] border border-[#1c2647] rounded-2xl p-6 space-y-4 shadow-xl">
                  <div className="flex items-center gap-2 text-cyan-400">
                    <UploadCloud className="w-5 h-5" />
                    <h2 className="text-md font-bold tracking-tight">Analyze Images (Vision)</h2>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {/* Drag and Drop/Input File */}
                    <div className="border border-dashed border-[#1c2647] hover:border-cyan-500/50 rounded-xl p-4 flex flex-col items-center justify-center text-center cursor-pointer relative bg-[#05070d]/40 transition">
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handleImageUpload}
                        className="absolute inset-0 opacity-0 cursor-pointer w-full h-full"
                      />
                      {analysisImage ? (
                        <img src={analysisImage} alt="Uploaded" className="max-h-28 rounded-lg object-contain" />
                      ) : (
                        <div className="space-y-1">
                          <UploadCloud className="w-8 h-8 text-[#8b98c9] mx-auto" />
                          <p className="text-xs text-[#8b98c9]">Drag &amp; drop atau klik untuk upload</p>
                          <span className="text-[10px] text-[#8b98c9]/60">JPEG/PNG maks 5MB</span>
                        </div>
                      )}
                    </div>

                    <div className="space-y-3">
                      <div className="space-y-1">
                        <label className="block text-xs text-[#8b98c9] font-mono">Analysis Prompt</label>
                        <input
                          type="text"
                          value={analysisPrompt}
                          onChange={(e) => setAnalysisPrompt(e.target.value)}
                          className="w-full bg-[#05070d] border border-[#1c2647] rounded-xl text-xs text-[#dbe4ff] p-2 outline-none focus:border-cyan-500"
                        />
                      </div>
                      <button
                        onClick={runImageAnalysis}
                        disabled={analyzingImage || !analysisImage}
                        className="w-full bg-cyan-500 hover:bg-cyan-600 disabled:opacity-50 text-[#04121a] font-bold py-2 px-4 rounded-xl flex items-center justify-center gap-2 transition text-xs cursor-pointer"
                      >
                        {analyzingImage ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Bot className="w-4 h-4" />}
                        <span>Analyze with Gemini Pro</span>
                      </button>
                    </div>
                  </div>

                  {analysisOutput && (
                    <div className="p-4 bg-[#05070d] border border-[#1c2647] rounded-xl max-h-48 overflow-y-auto">
                      <div className="text-[10px] text-[#8b98c9] font-mono border-b border-[#1c2647] pb-1 mb-2">VISION BREAKDOWN</div>
                      <p className="text-xs text-[#dbe4ff] leading-relaxed whitespace-pre-wrap">{analysisOutput}</p>
                    </div>
                  )}
                </div>
              </div>

              {/* Grounding (Search and Maps) */}
              <div className="bg-[#0b1020] border border-[#1c2647] rounded-2xl p-6 space-y-4 shadow-xl">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-cyan-400">
                    <Search className="w-5 h-5" />
                    <h2 className="text-md font-bold tracking-tight">Google Grounding Engine</h2>
                  </div>
                  <div className="flex items-center gap-1.5 bg-[#05070d] p-1 border border-[#1c2647] rounded-xl text-xs font-mono">
                    <button
                      onClick={() => setGroundingType("search")}
                      className={`px-3 py-1 rounded-lg transition ${
                        groundingType === "search" ? "bg-cyan-500/15 text-cyan-400" : "text-[#8b98c9]"
                      }`}
                    >
                      Search
                    </button>
                    <button
                      onClick={() => setGroundingType("maps")}
                      className={`px-3 py-1 rounded-lg transition ${
                        groundingType === "maps" ? "bg-cyan-500/15 text-cyan-400" : "text-[#8b98c9]"
                      }`}
                    >
                      Maps
                    </button>
                  </div>
                </div>

                <div className="flex gap-2">
                  <input
                    type="text"
                    value={groundingPrompt}
                    onChange={(e) => setGroundingPrompt(e.target.value)}
                    className="flex-1 bg-[#05070d] border border-[#1c2647] rounded-xl text-xs text-[#dbe4ff] p-3 outline-none focus:border-cyan-500"
                  />
                  <button
                    onClick={runGrounding}
                    disabled={loadingGrounding || !groundingPrompt.trim()}
                    className="bg-cyan-500 hover:bg-cyan-600 disabled:opacity-50 text-[#04121a] font-bold px-5 rounded-xl flex items-center justify-center gap-2 transition text-xs cursor-pointer"
                  >
                    {loadingGrounding ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />}
                    <span>Search</span>
                  </button>
                </div>

                {groundingOutput && (
                  <div className="p-4 bg-[#05070d] border border-[#1c2647] rounded-xl space-y-3">
                    <div className="text-[10px] text-[#8b98c9] font-mono border-b border-[#1c2647] pb-1">GROUNDED INSIGHTS</div>
                    <p className="text-xs text-[#dbe4ff] leading-relaxed whitespace-pre-wrap">{groundingOutput}</p>
                    
                    {groundingSources.length > 0 && (
                      <div className="space-y-1.5 pt-2 border-t border-[#1c2647]">
                        <span className="text-[10px] text-[#8b98c9] font-mono font-bold block">SOURCES &amp; REFERENCES:</span>
                        <div className="flex flex-wrap gap-2">
                          {groundingSources.map((src, i) => (
                            <a
                              key={i}
                              href={src.web?.uri || "#"}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-[10px] bg-[#0b1020] border border-[#1c2647] hover:border-cyan-500/40 text-cyan-400 px-2 py-1 rounded-lg flex items-center gap-1 transition"
                            >
                              <span>{src.web?.title || `Source ${i + 1}`}</span>
                              <ExternalLink className="w-3 h-3" />
                            </a>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB 3: FIRESTORE LIVE */}
          {activeTab === "workspace" && (
            <div className="animate-fade-in">
              {/* Firestore Live Chats Viewer Panel */}
              <div className="bg-[#0b1020] border border-[#1c2647] rounded-2xl p-6 space-y-4 shadow-xl flex flex-col justify-between max-w-2xl mx-auto">
                <div>
                  <div className="flex items-center gap-3 border-b border-[#1c2647] pb-4 mb-3">
                    <span className="w-3 h-3 bg-cyan-500 rounded-full animate-pulse shadow-[0_0_10px_#06b6d4]" />
                    <div>
                      <h2 className="text-lg font-bold tracking-tight text-[#dbe4ff]">Firestore Live Terminal</h2>
                      <p className="text-xs text-[#8b98c9]">Mengawasi data koleksi "chats" dari Firebase secara real-time</p>
                    </div>
                  </div>

                  <div className="bg-[#05070d] border border-[#1c2647] rounded-xl p-4 h-64 overflow-y-auto space-y-3">
                    {firestoreMsgs.length === 0 ? (
                      <div className="text-center py-14">
                        <p className="text-xs text-[#8b98c9] font-mono">
                          Mendengarkan Firestore chats: Terkoneksi.
                        </p>
                        <p className="text-[10px] text-[#8b98c9]/60 max-w-sm mx-auto mt-2">
                          Belum ada pesan log di koleksi ini. {currentUser ? "Jadilah yang pertama mengirimkan pesan!" : "Sign in untuk mengirimkan log pertama!"}
                        </p>
                        {!currentUser && (
                          <button
                            onClick={handleGlobalSignIn}
                            type="button"
                            className="mt-3 bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-400 font-bold text-xs px-4 py-2 border border-cyan-500/25 rounded-xl cursor-pointer transition mx-auto"
                          >
                            Sign In with Firebase
                          </button>
                        )}
                      </div>
                    ) : (
                      <div className="space-y-2">
                        {firestoreMsgs.map((msg) => (
                          <div key={msg.id} className="text-xs border-b border-[#1c2647]/50 pb-2">
                            <div className="flex items-center justify-between text-[10px] text-cyan-400 font-mono">
                              <span>{msg.userName}</span>
                              <span>{new Date(msg.timestamp).toLocaleTimeString()}</span>
                            </div>
                            <p className="text-[#dbe4ff] mt-0.5 font-sans leading-relaxed">
                              {privacyMode ? "••••••••••••••••" : msg.text}
                            </p>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>

                <form onSubmit={handleSendFirestoreMsg} className="flex gap-2">
                  <input
                    type="text"
                    placeholder={currentUser ? "Tulis log ke Firestore chats..." : "Sign in untuk menulis log..."}
                    disabled={!currentUser || loadingFb}
                    value={newFbMsg}
                    onChange={(e) => setNewFbMsg(e.target.value)}
                    className="flex-1 bg-[#05070d] border border-[#1c2647] disabled:opacity-40 rounded-xl text-xs text-[#dbe4ff] p-3 outline-none focus:border-cyan-500"
                  />
                  <button 
                    type="submit"
                    disabled={!currentUser || !newFbMsg.trim() || loadingFb}
                    className="bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 font-bold px-5 border border-cyan-500/30 disabled:opacity-40 rounded-xl text-xs transition cursor-pointer"
                  >
                    {loadingFb ? "Loading..." : "Simpan"}
                  </button>
                </form>
              </div>
            </div>
          )}

          {/* TAB 4: SETTINGS & SECRETS MANAGER */}
          {activeTab === "settings" && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 animate-fade-in">
              <div className="bg-[#0b1020] border border-[#1c2647] rounded-2xl p-6 space-y-5 shadow-xl">
                <div className="flex items-center gap-2 text-cyan-400 border-b border-[#1c2647] pb-3 mb-1">
                  <Settings className="w-5 h-5" />
                  <h2 className="text-md font-bold tracking-tight">Configuration Credentials</h2>
                </div>

                <form onSubmit={handleSaveConfig} className="space-y-4 text-xs font-mono">
                  <div className="space-y-1.5">
                    <label className="block text-[#8b98c9] uppercase tracking-wider">GEMINI API KEY</label>
                    <input
                      type="password"
                      value={config.GEMINI_API_KEY}
                      onChange={(e) => setConfig({ ...config, GEMINI_API_KEY: e.target.value })}
                      placeholder="Masukkan custom key jika ingin meng-override..."
                      className="w-full bg-[#05070d] border border-[#1c2647] rounded-xl p-3 text-[#dbe4ff] outline-none focus:border-cyan-500"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="block text-[#8b98c9] uppercase tracking-wider">FIREBASE PROJECT ID</label>
                    <input
                      type="text"
                      value={config.FIREBASE_PROJECT_ID}
                      onChange={(e) => setConfig({ ...config, FIREBASE_PROJECT_ID: e.target.value })}
                      className="w-full bg-[#05070d] border border-[#1c2647] rounded-xl p-3 text-[#dbe4ff] outline-none focus:border-cyan-500"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="block text-[#8b98c9] uppercase tracking-wider">FIREBASE API KEY</label>
                    <input
                      type="text"
                      value={config.FIREBASE_API_KEY}
                      onChange={(e) => setConfig({ ...config, FIREBASE_API_KEY: e.target.value })}
                      className="w-full bg-[#05070d] border border-[#1c2647] rounded-xl p-3 text-[#dbe4ff] outline-none focus:border-cyan-500"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="block text-[#8b98c9] uppercase tracking-wider">ORACLE VM PUBLIC IP</label>
                    <input
                      type="text"
                      value={config.ORACLE_VM_IP}
                      onChange={(e) => setConfig({ ...config, ORACLE_VM_IP: e.target.value })}
                      className="w-full bg-[#05070d] border border-[#1c2647] rounded-xl p-3 text-[#dbe4ff] outline-none focus:border-cyan-500"
                    />
                  </div>

                  <div className="pt-2 flex items-center justify-between">
                    <button
                      type="submit"
                      className="bg-cyan-500 hover:bg-cyan-600 text-[#04121a] font-bold py-2.5 px-6 rounded-xl transition text-xs font-sans cursor-pointer"
                    >
                      Auto Save Config
                    </button>
                    {configStatus && (
                      <span className="text-xs text-cyan-400 font-sans">{configStatus}</span>
                    )}
                  </div>
                </form>
              </div>

              {/* Cloned Repositories integration and info card */}
              <div className="bg-[#0b1020] border border-[#1c2647] rounded-2xl p-6 space-y-4 shadow-xl">
                <div className="flex items-center gap-2 text-cyan-400 border-b border-[#1c2647] pb-3">
                  <Cpu className="w-5 h-5" />
                  <h2 className="text-md font-bold tracking-tight">GitHub Repository Sync (roc-otoweb)</h2>
                </div>

                <div className="space-y-4 font-mono text-xs leading-relaxed">
                  <div className="bg-[#05070d] p-3.5 border border-[#1c2647] rounded-xl space-y-2">
                    <div className="flex items-center justify-between">
                      <p className="font-bold text-[#dbe4ff]">Target Private Repository:</p>
                      <span className="text-[10px] bg-cyan-500/10 text-cyan-400 px-2 py-0.5 rounded border border-cyan-500/20">Private Repo</span>
                    </div>
                    <a 
                      href="https://github.com/ivansslo/roc-otoweb" 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="text-cyan-400 hover:underline flex items-center gap-1 font-bold text-sm"
                    >
                      <span>ivansslo/roc-otoweb</span>
                      <ExternalLink className="w-3.5 h-3.5" />
                    </a>
                    <p className="text-[11px] text-[#8b98c9] font-sans">
                      Semua file project telah disinkronkan ke remote origin <code className="text-cyan-300">https://github.com/ivansslo/roc-otoweb.git</code>.
                    </p>
                  </div>

                  <div className="space-y-2">
                    <p className="font-bold text-[#8b98c9] uppercase tracking-wider text-[10px]">Panduan Push File ke GitHub (roc-otoweb)</p>
                    <div className="bg-[#05070d] border border-[#1c2647] p-3.5 rounded-xl space-y-2 text-[11px] text-[#dbe4ff]">
                      <p className="font-sans text-[#8b98c9]">Gunakan Personal Access Token (PAT) GitHub untuk melakukan push ke repository privat:</p>
                      <div className="bg-[#0b1020] p-2.5 rounded-lg border border-[#1c2647] font-mono text-cyan-300 space-y-1">
                        <div>git remote set-url origin https://&lt;YOUR_GITHUB_TOKEN&gt;@github.com/ivansslo/roc-otoweb.git</div>
                        <div>git add .</div>
                        <div>git commit -m "Push complete project files to roc-otoweb"</div>
                        <div>git push -u origin main</div>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <p className="font-bold text-[#8b98c9] uppercase tracking-wider text-[10px]">Active CLI Cheatsheet</p>
                    <div className="grid grid-cols-1 gap-1.5 text-[11px] bg-[#05070d] border border-[#1c2647] p-3.5 rounded-xl text-[#dbe4ff]">
                      <div><span className="text-cyan-400">hermes orchestrator &lt;task&gt;</span> — Plan-Code-Test loop</div>
                      <div><span className="text-cyan-400">hermes vm status</span> — Oracle VM status probe</div>
                      <div><span className="text-cyan-400">hermes coding</span> — Interactive script workspace</div>
                      <div><span className="text-cyan-400">hermes antigravity install</span> — Antigravity ARM64 IDE</div>
                    </div>
                  </div>

                  <div className="bg-cyan-500/5 border border-cyan-500/20 p-3.5 rounded-xl flex items-start gap-3">
                    <Shield className="w-5 h-5 text-cyan-400 shrink-0 mt-0.5" />
                    <p className="text-[#8b98c9] text-xs font-sans">
                      Semua key kredensial tersimpan secara privat pada server-side dan tidak pernah diekspos ke browser / client, menjamin mode keamanan penuh (Security compliance).
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}

        </main>

        {/* FOOTER */}
        <footer className="text-center text-[#8b98c9] text-xs font-mono py-8 border-t border-[#1c2647]">
          <p>© 2026 ROC AgentRoute · Hermes Control Hub · Powered by Gemini 3.1 &amp; Firestore Auto-Save</p>
        </footer>

      </div>
    </div>
  );
}
