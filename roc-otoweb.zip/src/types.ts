export interface Message {
  id: string;
  sender: "user" | "model";
  text: string;
  timestamp: string;
}

export interface AgentLog {
  actor: string;
  tool: string;
  toolInput?: string;
  dialogue: string;
  toolOutput?: string;
}

export interface AppConfig {
  GEMINI_API_KEY: string;
  FIREBASE_PROJECT_ID: string;
  FIREBASE_API_KEY: string;
  ORACLE_VM_IP: string;
  PRIVACY_MODE: boolean;
}

export interface TaskItem {
  id: string;
  title: string;
  notes?: string;
  status: "needsAction" | "completed";
  due?: string;
}
